/*
 * CatchIt Final‑Prototyp – Skript
 *
 * Diese Datei implementiert den zustandsbasierten Ablauf des Prototyps.  Sie
 * steuert die Darstellung der verschiedenen Modi (Zen, Planung, Vergleich,
 * Go, Recovery), erzeugt fiktive Alternativen und verwaltet den
 * Fortschritt innerhalb der Timeline.  Die Logik ist bewusst simpel
 * gehalten, um den Fokus auf die UX‑Flüsse zu legen.
 */

document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  const modeIndicator = document.getElementById('mode-indicator');
  const disruptionButton = document.getElementById('simulate-disruption');
  const cathyBubble = document.getElementById('cathy-bubble');

  // Zentraler Zustandsspeicher
  let currentState = 'zen';
  let currentPlan = null;
  let currentStepIndex = 0;
  let wizardData = {};
  let lastAlternatives = [];

  /**
   * Zeigt oder versteckt die Cathy‑Bubble.  Cathy bietet humane
   * Unterstützung; sie soll nur bei Bedarf sichtbar sein.
   * @param {boolean} show Ob die Bubble eingeblendet werden soll
   */
  function showCathy(show) {
    if (show) {
      cathyBubble.classList.remove('hidden');
    } else {
      cathyBubble.classList.add('hidden');
    }
  }

  /**
   * Aktualisiert den Modus‑Badge und dessen Farbe anhand einer CSS‑Variable.
   * @param {string} text Beschriftung des Mode‑Indicators
   * @param {string} colorVar CSS‑Variable für den Hintergrund
   */
  function setModeIndicator(text, colorVar) {
    modeIndicator.textContent = text;
    if (colorVar) {
      modeIndicator.style.backgroundColor = getComputedStyle(document.documentElement).getPropertyValue(colorVar);
    }
  }

  /**
   * Blendet den Störungsbutton ein oder aus.  Der Button soll nur im Go‑Modus
   * sichtbar sein, um eine Disruption zu simulieren.
   * @param {boolean} show Ob der Störungsbutton angezeigt wird
   */
  function toggleDisruptionButton(show) {
    disruptionButton.style.display = show ? 'inline-block' : 'none';
  }

  /**
   * Rendert die Zen‑Ansicht (Orientierung).  Wenn ein Plan aktiv ist,
   * wird er zusammen mit alternativen Routen dargestellt.  Andernfalls
   * wird der Nutzer eingeladen, einen neuen Plan zu erstellen.
   */
  function renderZen() {
    currentState = 'zen';
    setModeIndicator('Zen', '--color-stable');
    toggleDisruptionButton(false);
    showCathy(false);
    app.innerHTML = '';
    if (currentPlan) {
      // Karte zum aktuellen Plan
      const card = document.createElement('div');
      card.className = 'card';
      // Schätzung, wann der Nutzer losgehen sollte (vereinfachte Berechnung)
      const leaveIn = Math.max(Math.round(currentPlan.duration / 2), 1);
      card.innerHTML = `
        <h2>Aktueller Plan</h2>
        <p><strong>Route:</strong> ${currentPlan.name}</p>
        <p><strong>Ankunft:</strong> ${currentPlan.arrival}</p>
        <p><strong>Los in:</strong> ${leaveIn} min</p>
        <div class="wizard-actions">
          <button class="button" id="resume-plan">Fortsetzen</button>
          <button class="button secondary" id="new-plan">Neuen Plan erstellen</button>
        </div>
      `;
      app.appendChild(card);
      // Alternativen aus dem letzten Vergleich anzeigen
      if (lastAlternatives && lastAlternatives.length > 0) {
        const altWrapper = document.createElement('div');
        altWrapper.className = 'card';
        altWrapper.innerHTML = '<h3>Alternativen</h3>';
        const altGrid = document.createElement('div');
        altGrid.className = 'options-container';
        lastAlternatives.forEach((alt) => {
          const small = document.createElement('div');
          small.className = 'option-card';
          small.innerHTML = `
            <div class="role">${alt.role}</div>
            <h3>${alt.name}</h3>
            <div class="meta">Ankunft: ${alt.arrival}</div>
          `;
          small.addEventListener('click', () => {
            currentPlan = alt;
            renderExecution(currentPlan);
          });
          altGrid.appendChild(small);
        });
        altWrapper.appendChild(altGrid);
        app.appendChild(altWrapper);
      }
      document.getElementById('resume-plan').addEventListener('click', () => {
        renderExecution(currentPlan);
      });
      document.getElementById('new-plan').addEventListener('click', () => {
        currentPlan = null;
        renderWizard();
      });
    } else {
      // Kein Plan vorhanden: Aufforderung zur Planung
      const welcome = document.createElement('div');
      welcome.className = 'card';
      welcome.innerHTML = `
        <h2>Zen‑Ansicht</h2>
        <p>Willkommen bei CatchIt. Du hast aktuell noch keinen Plan.</p>
        <p>Erstelle einen neuen Plan, indem du dein Ziel und ein paar einfache Fragen beantwortest.</p>
        <button class="button" id="start-plan">Plan erstellen</button>
      `;
      app.appendChild(welcome);
      document.getElementById('start-plan').addEventListener('click', () => {
        renderWizard();
      });
    }
  }

  /**
   * Rendert die Wizard‑Eingaben (Plan‑Modus).  Der Nutzer gibt ein Ziel
   * sowie Präferenzen an.  Nach Abschluss werden die Ergebnisse in die
   * Vergleichsansicht überführt.
   */
  function renderWizard() {
    currentState = 'wizard';
    setModeIndicator('Planung', '--color-attentive');
    toggleDisruptionButton(false);
    showCathy(false);
    app.innerHTML = '';
    const container = document.createElement('div');
    container.className = 'card';
    container.innerHTML = `
      <h2>Planung: Dein Vorhaben</h2>
      <div class="wizard-step">
        <label for="destination">Wohin möchtest du?</label>
        <input type="text" id="destination" placeholder="z. B. Hauptbahnhof" required />
      </div>
      <div class="wizard-step">
        <label for="follow-up">Musst du danach noch weiter?</label>
        <select id="follow-up">
          <option value="nein">Nein</option>
          <option value="ja">Ja</option>
        </select>
      </div>
      <div class="wizard-step">
        <label for="walking">Wie stehst du zum Gehen?</label>
        <select id="walking">
          <option value="egal">Egal</option>
          <option value="viel">Ich gehe gern länger</option>
          <option value="wenig">Bitte wenig gehen</option>
        </select>
      </div>
      <div class="wizard-actions">
        <button class="button secondary" id="cancel-wizard">Abbrechen</button>
        <button class="button" id="submit-wizard">Optionen anzeigen</button>
      </div>
    `;
    app.appendChild(container);
    document.getElementById('cancel-wizard').addEventListener('click', () => {
      // Zurück zur Zen‑Ansicht ohne Änderungen
      renderZen();
    });
    document.getElementById('submit-wizard').addEventListener('click', () => {
      // Eingaben sammeln und validieren
      const dest = document.getElementById('destination').value.trim();
      if (!dest) {
        alert('Bitte gib dein Ziel an.');
        return;
      }
      wizardData.destination = dest;
      wizardData.followUp = document.getElementById('follow-up').value;
      wizardData.walking = document.getElementById('walking').value;
      renderComparison();
    });
  }

  /**
   * Generiert drei fiktive Alternativen basierend auf den Wizard‑Angaben.
   * Die Optionen variieren in Geschwindigkeit, Komfort und Robustheit.
   * @returns {Array<Object>} Liste von Alternativen
   */
  function generateAlternatives() {
    const dest = wizardData.destination;
    const follow = wizardData.followUp === 'ja';
    const walkingPref = wizardData.walking;
    const now = new Date();
    // Helfer zur Formatierung der Uhrzeit
    function format(time) {
      return time.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
    // Basisdauer abhängig vom Gehpräferenz
    const baseDuration = walkingPref === 'wenig' ? 30 : walkingPref === 'viel' ? 18 : 24;
    return [
      {
        id: 'best',
        role: 'Bestes Angebot',
        name: `S‑Bahn zum ${dest}`,
        description: 'Schnellste Route mit moderatem Gehen',
        duration: baseDuration,
        arrival: format(new Date(now.getTime() + baseDuration * 60000)),
        walking: walkingPref === 'viel' ? '20 min zu Fuß' : '8 min zu Fuß',
        notes: follow ? 'Beinhaltet Anschlussplanung' : 'Einfacher Direktweg'
      },
      {
        id: 'calm',
        role: 'Reserviert',
        name: `Tram zum ${dest}`,
        description: 'Mehr Komfort, weniger Tempo',
        duration: baseDuration + 6,
        arrival: format(new Date(now.getTime() + (baseDuration + 6) * 60000)),
        walking: '5 min zu Fuß',
        notes: 'Minimaler Stress, größere Puffer'
      },
      {
        id: 'fallback',
        role: 'Fallback',
        name: `Bus zum ${dest}`,
        description: 'Langsamer, aber robuste Option',
        duration: baseDuration + 12,
        arrival: format(new Date(now.getTime() + (baseDuration + 12) * 60000)),
        walking: '3 min zu Fuß',
        notes: 'Geeignet bei Störungen'
      }
    ];
  }

  /**
   * Rendert die Vergleichsansicht.  Der Nutzer wählt eine der
   * Alternativen aus, um in den Go‑Modus zu wechseln.
   */
  function renderComparison() {
    currentState = 'comparison';
    setModeIndicator('Vergleich', '--color-attentive');
    toggleDisruptionButton(false);
    showCathy(true);
    const alternatives = generateAlternatives();
    lastAlternatives = alternatives;
    currentPlan = null; // Reset plan selection
    app.innerHTML = '';
    const heading = document.createElement('h2');
    heading.textContent = 'Wähle eine Option';
    app.appendChild(heading);
    // Karten für Alternativen
    const grid = document.createElement('div');
    grid.className = 'options-container';
    alternatives.forEach((opt) => {
      const card = document.createElement('div');
      card.className = 'option-card';
      card.dataset.optId = opt.id;
      card.innerHTML = `
        <div class="role">${opt.role}</div>
        <h3>${opt.name}</h3>
        <div class="meta">Ankunft: ${opt.arrival} • Dauer: ${opt.duration} min • Gehen: ${opt.walking}</div>
        <div class="meta">${opt.notes}</div>
      `;
      card.addEventListener('click', () => {
        // Markiere Auswahl
        document.querySelectorAll('.option-card').forEach((c) => c.classList.remove('selected'));
        card.classList.add('selected');
        currentPlan = opt;
      });
      grid.appendChild(card);
    });
    app.appendChild(grid);
    // Navigationsbuttons
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button secondary" id="back-to-wizard">Zurück</button>
      <button class="button" id="select-plan">Weiter</button>
    `;
    app.appendChild(actions);
    document.getElementById('back-to-wizard').addEventListener('click', () => {
      renderWizard();
    });
    document.getElementById('select-plan').addEventListener('click', () => {
      if (!currentPlan) {
        alert('Bitte wähle eine Option aus.');
        return;
      }
      renderExecution(currentPlan);
    });
  }

  /**
   * Bereitet Schritte für die Timeline vor.  Der generische Ablauf lautet
   * »Zum Startpunkt gehen«, »Fahrt«, »Zum Ziel gehen«.  Jede Station hat
   * eine Dauer, die addiert werden könnte.  Hier verwenden wir
   * vereinfachte Zeiten.
   * @param {Object} plan Der ausgewählte Plan
   * @returns {Array<Object>} Liste von Schritten
   */
  function buildSteps(plan) {
    const steps = [];
    const start = new Date();
    const addMinutes = (date, mins) => new Date(date.getTime() + mins * 60000);
    let t = start;
    // Hilfsfunktion zur Formatierung
    const fmt = (d) => d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    // Startweg
    steps.push({ time: fmt(t), label: 'Zum Startpunkt gehen' });
    t = addMinutes(t, 5);
    // Fahrt
    const rideDuration = plan.duration - 8; // subtract walking on both sides
    steps.push({ time: fmt(t), label: plan.name });
    t = addMinutes(t, rideDuration);
    // Zielweg
    steps.push({ time: fmt(t), label: 'Zum Ziel gehen' });
    return steps;
  }

  /**
   * Rendert den Go‑Modus (Execution).  Zeigt Plan‑Details und eine
   * Timeline der bevorstehenden Schritte.  Der Nutzer kann den
   * Fortschritt manuell vorantreiben oder den Plan abbrechen.
   * @param {Object} plan Der Plan, der ausgeführt werden soll
   */
  function renderExecution(plan) {
    currentState = 'execution';
    currentPlan = plan;
    currentStepIndex = 0;
    setModeIndicator('Go‑Modus', '--color-stable');
    toggleDisruptionButton(true);
    showCathy(false);
    // Steps vorbereiten
    const steps = buildSteps(plan);
    app.innerHTML = '';
    // Kopfkarte mit Planinformationen
    const headerCard = document.createElement('div');
    headerCard.className = 'card';
    headerCard.innerHTML = `
      <h2>Aktueller Plan</h2>
      <p><strong>Route:</strong> ${plan.name}</p>
      <p><strong>Ankunftszeit:</strong> ${plan.arrival}</p>
      <p><strong>Dauer:</strong> ${plan.duration} min</p>
    `;
    app.appendChild(headerCard);
    // Timeline generieren
    const list = document.createElement('ul');
    list.className = 'timeline';
    steps.forEach((step, idx) => {
      const li = document.createElement('li');
      li.dataset.stepIndex = idx;
      li.classList.add(idx === 0 ? 'current' : 'upcoming');
      li.innerHTML = `
        <div class="step">
          <span class="timestamp">${step.time}</span>
          <span class="description">${step.label}</span>
        </div>
      `;
      list.appendChild(li);
    });
    app.appendChild(list);
    // Aktionsbuttons: nächster Schritt, Plan verlassen
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button" id="next-step">Nächster Schritt</button>
      <button class="button secondary" id="exit-plan">Plan verlassen</button>
    `;
    app.appendChild(actions);
    document.getElementById('next-step').addEventListener('click', () => {
      advanceStep(list);
    });
    document.getElementById('exit-plan').addEventListener('click', () => {
      // Plan abbrechen und zur Zen‑Ansicht zurückkehren
      renderZen();
    });
  }

  /**
   * Führt den Nutzer zum nächsten Schritt in der Timeline.  Die aktuelle
   * Station wird als »completed« markiert, die nächste als »current«.
   * Wird das Ende erreicht, wird der Plan als abgeschlossen markiert.
   * @param {HTMLElement} list Die UL‑Liste der Timeline
   */
  function advanceStep(list) {
    const items = list.querySelectorAll('li');
    if (currentStepIndex < items.length) {
      items[currentStepIndex].classList.remove('current');
      items[currentStepIndex].classList.add('completed');
      currentStepIndex++;
    }
    if (currentStepIndex < items.length) {
      items[currentStepIndex].classList.remove('upcoming');
      items[currentStepIndex].classList.add('current');
    } else {
      alert('Reise abgeschlossen!');
      renderZen();
    }
  }

  /**
   * Rendert den Recovery‑Modus (nach einer Störung).  Bietet zwei
   * Auswege an und ermöglicht den Abbruch der Reise.  Anschließend kehrt
   * der Flow in den Go‑Modus zurück oder zur Zen‑Ansicht, je nach
   * Auswahl.
   */
  function renderRecovery() {
    currentState = 'recovery';
    setModeIndicator('Recovery', '--color-urgent');
    toggleDisruptionButton(false);
    showCathy(true);
    app.innerHTML = '';
    const alertBox = document.createElement('div');
    alertBox.className = 'recovery';
    alertBox.innerHTML = `
      <h2>Störung erkannt</h2>
      <p>Es ist eine Störung aufgetreten. Deine ursprüngliche Route ist nicht mehr zuverlässig. Bitte wähle eine neue Option.</p>
    `;
    app.appendChild(alertBox);
    // Recovery‑Optionen
    const fallbackOptions = [
      {
        id: 'quick',
        title: 'Schnellster Ausweg',
        desc: 'Zurück zur letzten sicheren Station und alternativen Zug nehmen.'
      },
      {
        id: 'safe',
        title: 'Beruhigte Alternative',
        desc: 'Einen ruhigen Bus nehmen, der dich ans Ziel bringt.'
      }
    ];
    const optsDiv = document.createElement('div');
    optsDiv.className = 'options';
    fallbackOptions.forEach((opt) => {
      const card = document.createElement('div');
      card.className = 'option-card';
      card.innerHTML = `
        <h3>${opt.title}</h3>
        <p>${opt.desc}</p>
      `;
      card.addEventListener('click', () => {
        // Neues Planobjekt auf Basis des gewählten Fallbacks
        currentPlan = {
          name: opt.title,
          arrival: '–',
          duration: 20,
          walking: '5 min',
          notes: ''
        };
        renderExecution(currentPlan);
      });
      optsDiv.appendChild(card);
    });
    app.appendChild(optsDiv);
    // Abbruchbutton
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button secondary" id="cancel-recovery">Reise abbrechen</button>
    `;
    app.appendChild(actions);
    document.getElementById('cancel-recovery').addEventListener('click', () => {
      renderZen();
    });
  }

  // Ereignis: Störung simulieren, nur sinnvoll im Go‑Modus
  disruptionButton.addEventListener('click', () => {
    if (currentState === 'execution') {
      renderRecovery();
    }
  });

  // Startansicht
  renderZen();
});