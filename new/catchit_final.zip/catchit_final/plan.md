# CatchIt UX-Prototyp – Designplan und Endzustand

Dieser Plan beschreibt das Zielbild des CatchIt‑Prototyps, der sich an den Vorgaben aus den bereitgestellten Design‑Dokumenten orientiert.  Er liefert eine Blaupause für die Umsetzung des finalen Produkts und definiert die einzelnen Zustände, Ebenen und Designelemente, die das Erlebnis prägen.  Die Umsetzung konzentriert sich auf eine mobile Nutzungssituation und integriert die semantischen Leitplanken (Zen und Cathy) sowie die festgelegten Modi (Plan, Go, Recovery).

## Grundprinzipien

- **Decision Relief &amp; Reassurance**: CatchIt ist keine klassische Transit‑App, sondern ein System zur Entlastung bei Mobilitätsentscheidungen.  Es komprimiert die Mobilitätswahrheit so, dass Menschen weniger planen, weniger zweifeln, seltener nachschauen müssen und ihre Energie zielgerichtet einsetzen können.
- **Zustandsbasierte Architektur**: Alle Ansichten und Komponenten richten sich nach den Modi **Plan**, **Go** und **Recovery** sowie den UX‑Schichten **Orientation**, **Comparison**, **Transition**, **Execution** und **Reassurance**.  Jede Schicht bedient eine klar abgegrenzte Aufgabe im Nutzerfluss.
- **Zen &amp; Cathy**:  *Zen* steht für die ruhige, normative Darstellung von Informationen und Handlungsaufforderungen.  *Cathy* fungiert als humane Übersetzungsschicht und tritt nur dann auf, wenn der Nutzer empathische Begleitung oder Klarstellungen benötigt.  Cathy ist subtil in die Oberfläche integriert (als Chat‑Bubble), um die Kernlogik nicht zu überlagern.
- **Semantische Tokens**: Farben, Typografie, Abstände und weitere Gestaltungsmittel sind über Variablen abstrahiert.  Sie kodieren Zustände – stabil, aufmerksam, dringend – anstatt eine statische Markenästhetik festzulegen.  Dies ermöglicht eine spätere Anpassung an ein finales Design‑System.
- **Barrierefreiheit und kognitive Entlastung**: Die UI nutzt große Schrift, hohe Kontraste und eindeutige Sprachwahl.  Informationen werden so aufbereitet, dass sie den Nutzer nicht überfordern.  Alle Interaktionen sind in wenigen Schritten erledigbar; unnötige Eingaben oder Ablenkungen werden vermieden.

## Zustände und Flows

### Zen / Orientierungs‑Ansicht

Die Zen‑Ansicht bietet Überblick und Orientierung.  Sie zeigt den aktuellen Plan (wenn vorhanden), berechnet den nächsten sinnvollen Handlungszeitpunkt (»Los in X Minuten«) und listet weitere, kürzlich generierte Alternativen.  Der Nutzer kann den aktuellen Plan fortsetzen, eine alternative Route wählen oder einen neuen Plan erstellen.  In diesem Zustand ist Cathy nicht sichtbar; der Nutzer soll sich auf eine ruhige Informationsaufnahme konzentrieren.

### Plan‑Modus (Wizard / Comparison)

1. **Wizard**:  Ein kurzer Fragenkatalog ermittelt das Ziel, ob ein Anschluss geplant ist und wie es um die Gehbereitschaft steht.  Die Eingaben werden validiert (Pflichtfelder).  Nach Abschluss des Wizards werden passende Optionen generiert.
2. **Comparison**:  Drei Optionen werden in Kartenform präsentiert und tragen die Rollen **Bestes Angebot**, **Reserviert** und **Fallback**.  Diese Rollen verdeutlichen das Verhältnis von Schnelligkeit, Komfort und Robustheit.  Jede Karte enthält Route, Dauer, Ankunftszeit, Gehzeit und Kontextnotizen.  Der Nutzer wählt genau eine Option, um fortzufahren.  Cathy ist sichtbar, um humane Unterstützung bei der Entscheidung anzubieten.

### Go‑Modus (Execution / Timeline)

Im Go‑Modus wird der ausgewählte Plan Schritt für Schritt ausgeführt.  Der Bildschirm zeigt oben eine Zusammenfassung (Route, Ankunft, Dauer) und darunter eine **Timeline**.  Diese Timeline führt den Nutzer durch die drei generischen Phasen – **Startweg**, **Fahrt** und **Zielweg** –, markiert den aktuellen Schritt deutlich (farbliche Hervorhebung) und ermöglicht via »Nächster Schritt« das Fortschreiten.  Ein Abbruch (»Plan verlassen«) kehrt zur Zen‑Ansicht zurück.  Cathy bleibt im Hintergrund, da Klarheit und Fokus im Vordergrund stehen.

### Recovery‑Modus

Bei Störungen während der Ausführung (z. B. durch einen simulierten Disruptions‑Button) wechselt die UI in den Recovery‑Modus.  Eine auffällige Meldung erklärt, dass die ursprüngliche Route nicht mehr zuverlässig ist und zeigt zwei reduzierte Auswege: einen schnellen Pfad (zurück zur letzten sicheren Station) und eine beruhigte Alternative (Bus zum Ziel).  Der Nutzer entscheidet sich für einen Ausweg oder bricht die Reise ab.  Danach kehrt der Flow in den Go‑Modus zurück.

## Wichtige UI‑Elemente

| Element                    | Beschreibung                                                                                                                   |
|---------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| **Header mit Mode‑Badge** | Zeigt den aktuellen Modus an (Zen, Planung, Vergleich, Go, Recovery).  Die Badge‑Farbe leitet sich aus semantischen Token ab. |
| **Störung‑Button**        | Nur im Go‑Modus sichtbar; simuliert eine Disruption, um den Recovery‑Modus zu testen.                                            |
| **Cathy‑Bubble**          | Wird kontextabhängig angezeigt; öffnet (hier nur symbolisch) die humane Übersetzungsebene.                                       |
| **Karten**                | Zur Übersicht von Plänen, Alternativen und Recovery‑Optionen.  Klarer Titel, Metadaten, optionaler Aktionsbutton.                |
| **Wizard‑Form**           | Sammlung von Eingaben mit eindeutigen Labels und Validierung.                                                                    |
| **Option‑Cards**          | Interaktive Auswahlkarten mit Hover‑ und Selected‑Zustand zur Selektion eines Plans.                                            |
| **Timeline**              | Auflistung der Ausführungsschritte mit Zeitstempeln; aktuelle Position und Fortschritt sind farblich markiert.                 |
| **Buttons**               | Zwei Varianten: Primär (farbig) und Sekundär (grau).  Aktionen sind immer klar benannt (»Weiter«, »Abbrechen«, etc.).           |

## Endzustand‑Dateien

Der Prototyp besteht aus folgenden, vollständig ausgearbeiteten Dateien:

- **index.html** – Struktur der Seite mit einem „Telefonrahmen“, Header, Hauptbereich, Footer und der Cathy‑Bubble.  Der Hauptbereich wird dynamisch durch das Skript befüllt.
- **styles.css** – Neutrales, zustandsbasiertes Stylesheet mit CSS‑Variablen für Farben, Abstände und Typografie.  Die Gestaltung ist konsequent responsive und orientiert sich an einer 8‑pt‑Skala.
- **script.js** – Steuerung der gesamten Zustandslogik: Generierung von Alternativen, Rendering der Zen‑, Wizard‑, Vergleichs‑, Go‑ und Recovery‑Ansichten, Fortschreibung der Timeline sowie Event‑Handling.  Alle Interaktionen sind in diesem Skript zusammengefasst.
- **plan.md** (diese Datei) – Beschreibt das Konzept und dient als Dokumentation des Prototyps.

Diese Dateien sind so konzipiert, dass sie zusammenspielen und einen zusammenhängenden Ablauf ermöglichen.  Sie bilden eine solide Grundlage für eine künftige Integration in ein vollwertiges Design‑System und reale Datenquellen.