# CatchIt Screen Spec Pack v2

Dieses Paket enthält:
- 1 allgemeine Markdown-Vorlage
- 17 Kern-Screen-Specs
- 4 Zusatz-Screen-Specs für Trust / ND / Accessibility

Hinweis:
Die Kernfamilie umfasst 17 Zustände, weil die Main-State-Familie auf 5 Farben erweitert wurde:
Blue, Green, Yellow, Orange, Red.

## Struktur
- `00_master_template/` = leere Vorlage
- `01_core_states/` = Kernset
- `02_trust_nd_accessibility/` = Zusatzset

## Nutzung
Jede Datei kann direkt als Grundlage für:
- Design-Dokumentation
- Figma-Annotations
- Stakeholder-Präsentationen
- Stitch-/Prompt-Briefings

