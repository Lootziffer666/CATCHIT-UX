# Recovery / Kette angepasst

## Meta
- **Category:** C. Recovery und Vertrauenslogik
- **Priority:** P2
- **Sequence:** 12

## Core Definition
- **State Name:** Recovery / Kette angepasst
- **Short Definition:** Eine Änderung betrifft nicht nur einen Abschnitt, sondern den weiteren Ablauf der Kette.
- **Trigger:** Zwischenstopp, Rückweg, Folgeverpflichtung oder Zeitkorridor werden durch Änderung mitbeeinflusst
- **User Role:** Neue Gesamtlage verstehen, aber nicht alles neu planen müssen
- **CatchIt Role:** Kettenfolge neu sortieren und als weiter tragfähig darstellen
- **Primary Truth:** „Die Änderung betrifft mehr als diesen einen Schritt. Ich habe die Kette angepasst.“

## UI Behavior
- **Visible Elements:** knappe Kettenfortsetzung, geänderte Folgepunkte, klare neue Logik
- **Suppressed Elements:** Planungschaos, vollständige Neuberechnung als Textwand
- **Information Density:** mittel bis hoch, aber strukturiert
- **Tone:** ordnend, souverän, entlastend
- **Visual Consequence:** Kettenhaftigkeit wird sichtbar, ohne Projektplan-Charakter

## Boundaries
- **Must Not Mean:** Voll-Neuplanung durch den Nutzer
- **Kill Criteria:** Wenn die Kette nicht visuell verständlich wird, wenn zu viel Text nötig ist, wenn es wie ein kompliziertes Planungstool aussieht

## Notes
- Zeigt die Stärke von CatchIt gegenüber Standard-Apps.
