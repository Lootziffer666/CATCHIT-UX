# Spatial Assist / Map Focus

## Meta
- **Category:** B. Raum- und Exekutionslogik
- **Priority:** P1
- **Sequence:** 7

## Core Definition
- **State Name:** Spatial Assist / Map Focus
- **Short Definition:** Räumliche Orientierung wird dominanter, aber die Zeit- und Zustandswahrheit bleibt präsent.
- **Trigger:** Nutzer vertieft Raumhilfe oder nähert sich einem räumlich kritischen Moment
- **User Role:** Raum lesen, ohne den situativen Takt zu verlieren
- **CatchIt Role:** Karte lesbarer machen, aber Hauptlogik nicht aufgeben
- **Primary Truth:** „Die Orientierung wird gerade wichtiger, aber die Zeit bleibt maßgeblich.“

## UI Behavior
- **Visible Elements:** größere Kartenfläche, klarer Fußweg/Stop-Fokus, Zeitanker weiterhin sichtbar
- **Suppressed Elements:** reine Karten-App-Logik, Navigationschrome, überladene Kartendetails
- **Information Density:** mittel
- **Tone:** fokussiert, ruhig, situativ
- **Visual Consequence:** Karte gewinnt Raum, aber nicht die komplette Identität

## Boundaries
- **Must Not Mean:** Google Maps, turn-by-turn takeover
- **Kill Criteria:** Wenn Zeitinformation verschwindet, wenn die Oberfläche wie eine Standard-Navi wirkt, wenn CatchIt-Hierarchie verloren geht

## Notes
- Zeit bleibt Vertrauensanker.
