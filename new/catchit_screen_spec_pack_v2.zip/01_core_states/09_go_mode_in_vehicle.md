# Go Mode / In Vehicle

## Meta
- **Category:** B. Raum- und Exekutionslogik
- **Priority:** P2
- **Sequence:** 9

## Core Definition
- **State Name:** Go Mode / In Vehicle
- **Short Definition:** Exekutionszustand während der Fahrt. Weniger Losgehstress, mehr Begleitung und Übergangssicherheit.
- **Trigger:** Nutzer ist eingestiegen oder befindet sich in der Transportphase
- **User Role:** Folgen, beobachten, sich rechtzeitig vorbereiten
- **CatchIt Role:** Übergänge absichern, nächste Relevanz früh genug verdichten
- **Primary Truth:** „Du bist unterwegs. Ich halte den nächsten sinnvollen Punkt für dich im Blick.“

## UI Behavior
- **Visible Elements:** nächster relevanter Schritt, verbleibende Stops/Zeit, Umstiegsrelevanz, ruhige Zustandsführung
- **Suppressed Elements:** initiale Wizard-/Vergleichslogik, zu viele Planungsdetails
- **Information Density:** niedrig bis mittel
- **Tone:** begleitend, stabil, wachsam
- **Visual Consequence:** weniger Hektik als Walk-State, aber klare kommende Relevanz

## Boundaries
- **Must Not Mean:** reine Fahrtstatusanzeige ohne Handlungsperspektive
- **Kill Criteria:** Wenn der Screen passiv wird, wenn der nächste relevante Schritt nicht klar lesbar ist, wenn es wie Live-Tracking ohne Entlastung wirkt

## Notes
- Eher Begleitmodus als Analysemodus.
