# Wizard / Kettenfrage

## Meta
- **Category:** D. Planung und Ketten
- **Priority:** P1
- **Sequence:** 14

## Core Definition
- **State Name:** Wizard / Kettenfrage
- **Short Definition:** CatchIt klärt, ob es um einen einzelnen Weg oder einen Tages-/Pflichtablauf mit Folgepunkten geht.
- **Trigger:** Nach Wizard-Einstieg oder bei erkennbarer Mehrfachlogik
- **User Role:** Art des Vorhabens beschreiben
- **CatchIt Role:** Kettenlogik früh und einfach erfassen
- **Primary Truth:** „Geht es nur um einen Weg, oder hängt heute mehr daran?“

## UI Behavior
- **Visible Elements:** alltagsnahe Frageform, einfache Auswahl-/Antwortstruktur
- **Suppressed Elements:** Flowcharts, komplexe Multi-Step-Builder
- **Information Density:** niedrig
- **Tone:** pragmatisch, lebensnah
- **Visual Consequence:** Kettenlogik erscheint als normaler Alltag, nicht als Sonderfunktion

## Boundaries
- **Must Not Mean:** Projektplanung, Business-Workflow
- **Kill Criteria:** Wenn Nutzer die Frage nicht sofort versteht, wenn Kette technisch statt lebensnah wirkt, wenn die UI zu builder-artig wird

## Notes
- Einer der wichtigsten Wizard-Screens.
