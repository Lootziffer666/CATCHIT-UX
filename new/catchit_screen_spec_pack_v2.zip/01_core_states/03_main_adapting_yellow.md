# Main / Adapting / Yellow

## Meta
- **Category:** A. Kernzustände
- **Priority:** P1
- **Sequence:** 3

## Core Definition
- **State Name:** Main / Adapting / Yellow
- **Short Definition:** Eine Änderung wurde erkannt. CatchIt reagiert bereits und versucht, wieder auf eine tragfähige Lage zu kommen.
- **Trigger:** Verspätung, veränderte Lage, fragliche Anschlusslage, Alternativpfad wird geprüft oder vorbereitet.
- **User Role:** Noch nicht handeln müssen, aber offen für eine Anpassung bleiben.
- **CatchIt Role:** Kompensieren, neu bewerten, alternative tragfähige Wege vorbereiten.
- **Primary Truth:** „Etwas hat sich verändert. Ich kümmere mich.“

## UI Behavior
- **Visible Elements:** weiter Countdown + Optionen, Hinweis auf veränderte Lage, subtile Zeichen von Anpassung, evtl. neue Passungsmarker
- **Suppressed Elements:** harte Alarmästhetik, finale Handlungsaufforderung, Rot-Semantik
- **Information Density:** mittel
- **Tone:** aufmerksam, regulierend, kontrolliert
- **Visual Consequence:** leichte Reibung sichtbar, aber keine Panik; Änderung ist lesbar, ohne zum Problem-UI zu kippen

## Boundaries
- **Must Not Mean:** Warnung, Scheitern, sofort handeln
- **Kill Criteria:** Wenn Gelb wie Orange aussieht, wenn es wie eine Fehlermeldung wirkt, wenn keine aktive CatchIt-Reaktion erkennbar ist

## Notes
- Gelb ist Reaktionsfarbe, keine Alarmfarbe.
