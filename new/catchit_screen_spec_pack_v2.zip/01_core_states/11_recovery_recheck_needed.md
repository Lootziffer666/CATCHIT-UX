# Recovery / Recheck nötig

## Meta
- **Category:** C. Recovery und Vertrauenslogik
- **Priority:** P1
- **Sequence:** 11

## Core Definition
- **State Name:** Recovery / Recheck nötig
- **Short Definition:** CatchIt kann die Lage nicht glatt genug halten und braucht erneute Nutzeraufmerksamkeit.
- **Trigger:** Datenlage unsicher, Alternativen nicht belastbar genug, neue Prüfung nötig
- **User Role:** Nochmal hinschauen, aktiv bestätigen oder neu bewerten
- **CatchIt Role:** Ehrlich Unsicherheit markieren, ohne Vertrauen zu verspielen
- **Primary Truth:** „Ich kann das gerade nicht sauber genug für dich übernehmen. Bitte prüf nochmal.“

## UI Behavior
- **Visible Elements:** Unsicherheitsgrund, Recheck-Aufforderung, reduzierte klare Optionen
- **Suppressed Elements:** falsche Sicherheit, beschönigende Sprache
- **Information Density:** mittel
- **Tone:** ehrlich, nüchtern, respektvoll
- **Visual Consequence:** nicht alarmistisch, aber klar von Simple Switch getrennt

## Boundaries
- **Must Not Mean:** generischer Fehler, technischer Defekt, bloßes Gelb
- **Kill Criteria:** Wenn unklar bleibt, warum Recheck nötig ist, wenn der Nutzer keine klare nächste Handlung erkennt, wenn der Zustand sich wie ein App-Bug anfühlt

## Notes
- Ehrlichkeitszustand, kein Fehlercenter.
