# Main / Failed / Red

## Meta
- **Category:** A. Kernzustände
- **Priority:** P1
- **Sequence:** 5

## Core Definition
- **State Name:** Main / Failed / Red
- **Short Definition:** Diese konkrete Option oder Kette ist sicher nicht mehr tragfähig.
- **Trigger:** Anschluss sicher verpasst, Route nicht mehr rettbar, Zeitfenster faktisch gebrochen.
- **User Role:** Alte Lösung loslassen. Neue Realität akzeptieren.
- **CatchIt Role:** Klar benennen, nicht beschönigen, neue Basis vorbereiten.
- **Primary Truth:** „Das klappt so nicht mehr.“

## UI Behavior
- **Visible Elements:** eindeutige Problembennung, ggf. neue nächste tragfähige Basis, minimale Rettungs-/Neustartlogik
- **Suppressed Elements:** kosmetische Zuversicht, weiche Sprache, unnötige Optimierungsdetails
- **Information Density:** fokussiert niedrig bis mittel
- **Tone:** selten, klar, hart, ehrlich
- **Visual Consequence:** Rot nur in eindeutigen Scheiterfällen, kein dekorativer Einsatz

## Boundaries
- **Must Not Mean:** knapp, fraglich, bitte beeilen
- **Kill Criteria:** Wenn Rot für bloße Unsicherheit genutzt wird, wenn es wie Orange-plus aussieht, wenn rote Zustände zu häufig auftreten

## Notes
- Rot extrem sparsam nutzen.
