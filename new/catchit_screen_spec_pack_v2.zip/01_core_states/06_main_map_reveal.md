# Spatial Assist / Map Reveal

## Meta
- **Category:** B. Raum- und Exekutionslogik
- **Priority:** P1
- **Sequence:** 6

## Core Definition
- **State Name:** Spatial Assist / Map Reveal
- **Short Definition:** Der Main Screen verdichtet sich, und aus dem unteren Bereich wird räumliche Unterstützung freigelegt.
- **Trigger:** Swipe-up, situativer Bedarf nach räumlicher Sicherheit, Annäherung an Exekution
- **User Role:** Räumlich absichern, ohne den Kernscreen zu verlassen
- **CatchIt Role:** Orientierung ergänzen, nicht übernehmen
- **Primary Truth:** „Hier ist zusätzliche Raumhilfe, ohne dass du die Hauptwahrheit verlierst.“

## UI Behavior
- **Visible Elements:** gleiche Bubble-Hierarchie, gleiche Optionen, weich eingeblendete Map-Zone unten
- **Suppressed Elements:** Bottom Sheet, separater Kartenscreen, modulare Dashboard-Blöcke
- **Information Density:** mittel
- **Tone:** ruhig, eingebettet, unterstützend
- **Visual Consequence:** gleiche Oberfläche, höhere Dichte, Karte als untere Schicht

## Boundaries
- **Must Not Mean:** Map mode, Screenwechsel, Navigation takeover
- **Kill Criteria:** Wenn die Karte der Hero wird, wenn ein Bottom Sheet sichtbar ist, wenn die Bubble zur Nebenfigur schrumpft

## Notes
- Soft lower reveal, nicht klassischer Drawer.
