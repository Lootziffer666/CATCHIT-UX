# Main / Ready / Green

## Meta
- **Category:** A. Kernzustände
- **Priority:** P1
- **Sequence:** 2

## Core Definition
- **State Name:** Main / Ready / Green
- **Short Definition:** Jetzt wird es relevant, aber der Ablauf ist gut tragfähig.
- **Trigger:** Ein sinnvoller Handlungszeitpunkt nähert sich. Keine problematische Änderung, keine nötige Umplanung.
- **User Role:** Mental bereit sein, bald handeln können.
- **CatchIt Role:** Relevanz erhöhen, ohne Stress zu erzeugen.
- **Primary Truth:** „Jetzt wird es wichtig, aber du bist gut aufgestellt.“

## UI Behavior
- **Visible Elements:** Countdown-Bubble, 3 Optionen, leicht stärkere operative Zuspitzung, ggf. klarerer Fokus auf die plausibelste aktuelle Option
- **Suppressed Elements:** Karte, Recovery, übermäßige Vergleichstiefe
- **Information Density:** niedrig bis leicht erhöht
- **Tone:** zuversichtlich, vorbereitet, wach
- **Visual Consequence:** gleiche Hierarchie wie Blau, aber spürbar mehr Relevanz

## Boundaries
- **Must Not Mean:** Sieg, Optimierung, mathematisch beste Route
- **Kill Criteria:** Wenn Grün wie Alarm wirkt, wenn der Unterschied zu Blau nur dekorativ ist, wenn der Screen schon wie Exekution aussieht

## Notes
- Farbwechsel darf funktional, nicht nur dekorativ sein.
