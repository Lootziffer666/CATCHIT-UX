# Go Mode / Walk to Stop

## Meta
- **Category:** B. Raum- und Exekutionslogik
- **Priority:** P1
- **Sequence:** 8

## Core Definition
- **State Name:** Go Mode / Walk to Stop
- **Short Definition:** Exekutionszustand für den Weg zur Haltestelle. Denken runter, Handeln rauf.
- **Trigger:** Nutzer muss jetzt losgehen, um die tragfähige Option zu erreichen
- **User Role:** Gehen
- **CatchIt Role:** Nächsten Schritt maximal klar und belastungsarm machen
- **Primary Truth:** „Jetzt losgehen. Das ist der Weg.“

## UI Behavior
- **Visible Elements:** verbleibende Zeit, verbleibender Weg, Zielhaltestelle, ruhige Raumhilfe
- **Suppressed Elements:** Mehrfachvergleiche, breite Kettenübersicht, unnötige Nebendetails
- **Information Density:** fokussiert
- **Tone:** direkt, ruhig, körpernah
- **Visual Consequence:** große Klarheit, wenig Auswahl, hohe Exekutionslesbarkeit

## Boundaries
- **Must Not Mean:** normales Navigationstool, Sport-/Tracking-App
- **Kill Criteria:** Wenn der Screen wieder zum Analysieren einlädt, wenn zu viele alternative Optionen sichtbar bleiben, wenn die Handlung nicht eindeutig ist

## Notes
- Wahrscheinlich wichtigster Handlungszustand.
