# Wizard / Bewegungsstil / Tageslage

## Meta
- **Category:** D. Planung und Ketten
- **Priority:** P2
- **Sequence:** 15

## Core Definition
- **State Name:** Wizard / Bewegungsstil / Tageslage
- **Short Definition:** Präferenzen und aktuelle Belastungsfaktoren werden so erhoben, dass spätere Vorschläge realistisch passen.
- **Trigger:** Nach Kettenfrage oder bei relevanter Profilbildung
- **User Role:** Bewegungsrealität und Tagesbesonderheiten angeben
- **CatchIt Role:** Reibungsprofil statt Settings-Liste erfassen
- **Primary Truth:** „Was heute oder grundsätzlich deine Bewegung verändert, soll mitgedacht werden.“

## UI Behavior
- **Visible Elements:** einfache Auswahlfelder, alltagsnahe Formulierungen, kind-/stress-/geh-/wartebezogene Faktoren
- **Suppressed Elements:** technische Filter, schwere Parameterbegriffe
- **Information Density:** niedrig bis mittel
- **Tone:** empathisch, praktisch, unprätentiös
- **Visual Consequence:** kein Klinik-/Assessment-Gefühl, keine Settings-Hölle

## Boundaries
- **Must Not Mean:** Diagnostik, Profiling, Formularprüfung
- **Kill Criteria:** Wenn die Fragen klinisch oder technisch wirken, wenn Antworten später nicht sichtbar auf Vorschläge einzahlen, wenn es wie versteckte Settings wirkt

## Notes
- Tageslage von stabilen Präferenzen abgrenzen.
