# Recovery / Simple Switch

## Meta
- **Category:** C. Recovery und Vertrauenslogik
- **Priority:** P1
- **Sequence:** 10

## Core Definition
- **State Name:** Recovery / Simple Switch
- **Short Definition:** CatchIt hat eine neue tragfähige Alternative gefunden, ohne den Nutzer unnötig zu belasten.
- **Trigger:** Ursprüngliche Option wird schlechter, aber eine einfache passende Alternative steht bereit
- **User Role:** Zur Kenntnis nehmen, ggf. minimal mitgehen
- **CatchIt Role:** Änderung erklären, ohne Drama zu erzeugen
- **Primary Truth:** „Es hat sich geändert. Ich habe eine einfache passende Alternative.“

## UI Behavior
- **Visible Elements:** neue Option, knappe Begründung, klare Fortsetzung
- **Suppressed Elements:** große Problemkommunikation, Alternativenflut
- **Information Density:** mittel
- **Tone:** beruhigend, kompetent, kurz
- **Visual Consequence:** Recovery als Entlastung, nicht als Fehlerzustand

## Boundaries
- **Must Not Mean:** Fail, Alarm, unkontrollierte Lage
- **Kill Criteria:** Wenn Recovery wie ein Defekt wirkt, wenn zu viele Wahlmöglichkeiten wieder aufgemacht werden, wenn die neue Tragfähigkeit nicht klar ist

## Notes
- Einfachster Recovery-Fall zuerst.
