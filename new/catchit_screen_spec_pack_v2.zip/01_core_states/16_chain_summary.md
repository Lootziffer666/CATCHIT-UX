# Chain Summary

## Meta
- **Category:** D. Planung und Ketten
- **Priority:** P1
- **Sequence:** 16

## Core Definition
- **State Name:** Chain Summary
- **Short Definition:** CatchIt zeigt, was es aus Vorhaben und Präferenzen verstanden hat und wie daraus tragfähige Vorschläge entstehen.
- **Trigger:** Abschluss des Wizards oder relevante Neujustierung
- **User Role:** Verstanden fühlen, ggf. leicht korrigieren
- **CatchIt Role:** Verarbeitetes Alltagsmodell sichtbar machen
- **Primary Truth:** „So denke ich deinen Ablauf und deine Bewegungsrealität mit.“

## UI Behavior
- **Visible Elements:** ruhige Kettenübersicht, Präferenzhinweise, verständliche Zusammenfassung
- **Suppressed Elements:** Settings-Review-Look, rohe Parameterlisten
- **Information Density:** mittel
- **Tone:** ordnend, vertrauensbildend
- **Visual Consequence:** Summary wirkt wie Verständnis, nicht wie Konfiguration

## Boundaries
- **Must Not Mean:** „Bitte kontrollieren Sie 27 Optionen“
- **Kill Criteria:** Wenn die Summary wie ein Einstellungsmenü aussieht, wenn kein klarer Bezug zu späteren Vorschlägen entsteht, wenn zu viel technische Sprache auftaucht

## Notes
- Wichtiger Vertrauensscreen.
