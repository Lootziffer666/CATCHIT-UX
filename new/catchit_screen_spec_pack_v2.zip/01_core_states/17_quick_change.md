# Quick Change

## Meta
- **Category:** D. Planung und Ketten
- **Priority:** P1
- **Sequence:** 17

## Core Definition
- **State Name:** Quick Change
- **Short Definition:** Spontane Abweichung wird in die Kette integriert, ohne alles zu zerstören.
- **Trigger:** Nutzer möchte kurz etwas einbauen, verschieben oder einen späteren Bus nehmen
- **User Role:** Abweichung äußern, nicht neu planen
- **CatchIt Role:** Flexibel umsortieren, Tragfähigkeit erhalten
- **Primary Truth:** „Eine kleine Änderung muss nicht den ganzen Ablauf kaputtmachen.“

## UI Behavior
- **Visible Elements:** kleine Änderungsoption, neue plausible Kettenfortsetzung, knappe Auswirkung
- **Suppressed Elements:** Voll-Neuplanung, lange Listen, komplexe Optionenbäume
- **Information Density:** mittel
- **Tone:** flexibel, gelassen, lösungsorientiert
- **Visual Consequence:** Quick Change fühlt sich leicht an, nicht wie ein großer Eingriff

## Boundaries
- **Must Not Mean:** kompletter Rebuild, chaotische Re-Optimierung
- **Kill Criteria:** Wenn die Änderung zu viel UI-Komplexität erzeugt, wenn der Nutzer wieder alles entscheiden muss, wenn Kettenrobustheit nicht sichtbar wird

## Notes
- Wichtiger Pitch-Screen.
