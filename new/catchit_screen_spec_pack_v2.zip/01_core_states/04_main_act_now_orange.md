# Main / Act Now / Orange

## Meta
- **Category:** A. Kernzustände
- **Priority:** P1
- **Sequence:** 4

## Core Definition
- **State Name:** Main / Act Now / Orange
- **Short Definition:** Eine sinnvolle Lösung ist vorhanden, aber jetzt ist Nutzerhandlung nötig.
- **Trigger:** Der Nutzer muss jetzt losgehen, wechseln, reagieren oder sich für eine noch tragfähige Option entscheiden.
- **User Role:** Handeln. Nicht mehr nur beobachten.
- **CatchIt Role:** Interpretationslast reduzieren, nächsten Schritt glasklar machen.
- **Primary Truth:** „Jetzt handeln, dann bleibt es machbar.“

## UI Behavior
- **Visible Elements:** klare Exekutionssignale, verdichtete Informationen, nächste Handlung prominent, ggf. Raumhilfe/Karte stärker zugänglich
- **Suppressed Elements:** breite Vergleichsinfos, ruhige Neutralität, unnötige Nebendetails
- **Information Density:** mittel bis hoch, aber fokussiert
- **Tone:** direkt, klar, exekutiv
- **Visual Consequence:** stärkere Verdichtung, weniger Optionalität, Fokus auf nächste Aktion

## Boundaries
- **Must Not Mean:** gescheitert, hoffnungslos, final verloren
- **Kill Criteria:** Wenn Orange wie Rot aussieht, wenn der Nutzer nicht sofort versteht, was zu tun ist, wenn zu viele Optionen gleichzeitig sichtbar bleiben

## Notes
- Orange = noch machbar, aber nicht mehr passiv.
