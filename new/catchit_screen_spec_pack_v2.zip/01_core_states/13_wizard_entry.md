# Wizard / Einstieg

## Meta
- **Category:** D. Planung und Ketten
- **Priority:** P2
- **Sequence:** 13

## Core Definition
- **State Name:** Wizard / Einstieg
- **Short Definition:** CatchIt erklärt seinen Nutzen über Vorhaben und Alltag, nicht über Settings.
- **Trigger:** Erstnutzung oder relevante Neueinrichtung
- **User Role:** Vorhaben und Bewegungsrealität grob mitteilen
- **CatchIt Role:** Vertrauen aufbauen, nicht wie Setup wirken
- **Primary Truth:** „Ich will verstehen, wie du unterwegs wirklich funktionieren musst.“

## UI Behavior
- **Visible Elements:** einfache, lebensnahe Einstiegsfrage, klare Nutzenkommunikation
- **Suppressed Elements:** Fachparameter, Schalterfriedhof, technische Begriffe
- **Information Density:** niedrig
- **Tone:** freundlich, konkret, alltagsnah
- **Visual Consequence:** Wizard fühlt sich wie Hilfe an, nicht wie Konfiguration

## Boundaries
- **Must Not Mean:** Onboarding-Showcase, Formularstrecke
- **Kill Criteria:** Wenn es wie Settings aussieht, wenn zu viele Entscheidungen auf einmal verlangt werden, wenn der Produktnutzen nicht sofort klar wird

## Notes
- Settings-Dschungel aktiv vermeiden.
