# Main / Idle / Blue

## Meta
- **Category:** A. Kernzustände
- **Priority:** P1
- **Sequence:** 1

## Core Definition
- **State Name:** Main / Idle / Blue
- **Short Definition:** Noch kein akuter Handlungsdruck. CatchIt hält die Lage ruhig, klar und lesbar.
- **Trigger:** Route/Kette ist vorhanden, aber noch nicht operativ relevant. Keine störende Abweichung, kein unmittelbarer Entscheidungsdruck.
- **User Role:** Beobachten dürfen, nicht nachdenken müssen.
- **CatchIt Role:** Überwachen, beruhigen, vorverdichten, aber nicht zuspitzen.
- **Primary Truth:** „Es ist alles vorbereitet. Noch ist nichts akut.“

## UI Behavior
- **Visible Elements:** große Countdown-Bubble, 3 präferenzgebundene Optionen, ruhige Grundstruktur, minimale Zusatzinfos
- **Suppressed Elements:** Karte, Recovery-Logik, aggressive Statussignale, detaillierte Vergleichsinfos
- **Information Density:** niedrig
- **Tone:** ruhig, souverän, beiläufig präsent
- **Visual Consequence:** viel Luft, stabile Vertikalachse, keine operative Verdichtung

## Boundaries
- **Must Not Mean:** leer, unwichtig, datenarm, passiv
- **Kill Criteria:** Wenn der Screen wie eine Startseite ohne Relevanz wirkt, wenn schon Hektik entsteht, wenn zu viele Details sichtbar sind, wenn die 3 Optionen wie Suchresultate aussehen

## Notes
- Parent-State der Oberfläche.
