# Neutral Label vs User Label

## Meta
- **Category:** Trust / ND / Accessibility
- **Priority:** P3
- **Sequence:** 18

## Core Definition
- **State Name:** Neutral Label vs User Label
- **Short Definition:** Zeigt die Differenz zwischen neutraler Außendarstellung und persönlicher Bedeutung.
- **Trigger:** Bedarf nach sozial robuster Darstellung auf geteilten/öffentlichen Screens
- **User Role:** Sich geschützt fühlen, ohne Funktion zu verlieren
- **CatchIt Role:** Private Bedeutung abstrahieren, Kontext schützen
- **Primary Truth:** „Die Funktion bleibt, ohne unnötig private Details nach außen zu tragen.“

## UI Behavior
- **Visible Elements:** neutrale Labels, diskrete semantische Ebene, ggf. persönliche Bedeutung erst im geschützten Kontext
- **Suppressed Elements:** bloßstellende Formulierungen, intime Details im Klartext
- **Information Density:** niedrig
- **Tone:** diskret, respektvoll, sozial robust
- **Visual Consequence:** Bedeutung bleibt erhalten, aber Außenwirkung wird entschärft

## Boundaries
- **Must Not Mean:** Beliebigkeit, Funktionsverlust
- **Kill Criteria:** Wenn neutrale Labels unverständlich werden, wenn private Semantik unnötig sichtbar bleibt, wenn Schutz kompliziert wirkt

## Notes
- Wichtig für Privacy- und ND-Haltung.
