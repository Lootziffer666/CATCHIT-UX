# Voice-safe Assist Screen

## Meta
- **Category:** Trust / ND / Accessibility
- **Priority:** P4
- **Sequence:** 21

## Core Definition
- **State Name:** Voice-safe Assist Screen
- **Short Definition:** Sprach-/Audio-Unterstützung ohne soziale Peinlichkeit oder Privacy-Falle.
- **Trigger:** Bedarf nach schneller Assistenz mit möglicher Sprach- oder Audioausgabe
- **User Role:** Unterstützung nutzen können, ohne sich exponiert zu fühlen
- **CatchIt Role:** Voice-/Assist-Hilfe sozial sicher und knapp halten
- **Primary Truth:** „Assistenz hilft, ohne dich unnötig sichtbar oder hörbar zu machen.“

## UI Behavior
- **Visible Elements:** diskrete Assist-Optionen, visuelle Alternative, kurze sichere Audio-/Voice-Interaktion
- **Suppressed Elements:** lange Sprachausgaben, intime Details laut, aufdringliche Assistentenästhetik
- **Information Density:** niedrig bis mittel
- **Tone:** diskret, sicher, unaufdringlich
- **Visual Consequence:** Assistenz als Schutz, nicht als Show

## Boundaries
- **Must Not Mean:** smarte Lautstärke-Show, Assistenten-Theater
- **Kill Criteria:** Wenn Voice peinlich oder privatheitsgefährdend wird, wenn der Screen zu assistant-zentriert wirkt, wenn keine stille Alternative angeboten wird

## Notes
- Optional, aber stark für Haltung.
