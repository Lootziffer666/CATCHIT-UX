# Lockscreen-safe Notification

## Meta
- **Category:** Trust / ND / Accessibility
- **Priority:** P3
- **Sequence:** 19

## Core Definition
- **State Name:** Lockscreen-safe Notification
- **Short Definition:** Relevante Benachrichtigung ohne unnötige Preisgabe privater Kontexte.
- **Trigger:** Sperrbildschirm-Situation, öffentlicher Raum, flüchtige Sichtbarkeit
- **User Role:** Schnell verstehen, ohne exponiert zu werden
- **CatchIt Role:** Minimal relevante Wahrheit liefern, ohne intime Details zu zeigen
- **Primary Truth:** „Du bekommst genug Information zum Handeln, aber nicht mehr als nötig nach außen.“

## UI Behavior
- **Visible Elements:** knappe Relevanz, sichere Formulierungen, handlungsnahe Information
- **Suppressed Elements:** zu genaue Termine, intime Orts-/Anlassdetails, erklärende Texte
- **Information Density:** niedrig
- **Tone:** diskret, präzise, handlungsnah
- **Visual Consequence:** Hohe Lesbarkeit bei minimaler Exposition

## Boundaries
- **Must Not Mean:** leere Nichtssagung oder over-sharing
- **Kill Criteria:** Wenn die Notification privat bloßstellt, wenn sie unklar bleibt, wenn sie nach klassischer lauter Reminder-App aussieht

## Notes
- Lockscreen ist sozialer Raum.
