# Accessibility Variant / Large Text + Reduced Motion

## Meta
- **Category:** Trust / ND / Accessibility
- **Priority:** P3
- **Sequence:** 20

## Core Definition
- **State Name:** Accessibility Variant / Large Text + Reduced Motion
- **Short Definition:** Das System bleibt auch mit größerem Text und reduzierter Bewegung stabil lesbar.
- **Trigger:** Accessibility-Einstellung aktiv, Seh-/Verarbeitungsentlastung nötig
- **User Role:** Weiterhin sicher lesen und handeln können
- **CatchIt Role:** Hierarchie auch unter Einschränkungen robust halten
- **Primary Truth:** „Die Oberfläche bleibt tragfähig, auch wenn Darstellung angepasst werden muss.“

## UI Behavior
- **Visible Elements:** größere Typografie, reduzierte Animation, klare Abstände, unveränderte Semantik
- **Suppressed Elements:** mikrotypografische Spielereien, zu dichte Layouts, motion-abhängige Bedeutung
- **Information Density:** mittel
- **Tone:** ruhig, robust, barrierebewusst
- **Visual Consequence:** Gleiche Logik, andere Darstellungsschärfe

## Boundaries
- **Must Not Mean:** Sondermodus zweiter Klasse
- **Kill Criteria:** Wenn die Hierarchie zusammenbricht, wenn große Schrift die Kernwahrheit verdrängt, wenn Motion-Entzug die State-Logik zerstört

## Notes
- Nicht nur skalieren, semantisch mitdenken.
