# {{screen_name}}

## Meta
- **Category:** {{category}}
- **Priority:** {{priority}}
- **Sequence:** {{sequence}}

## Core Definition
- **State Name:** {{state_name}}
- **Short Definition:** {{short_definition}}
- **Trigger:** {{trigger}}
- **User Role:** {{user_role}}
- **CatchIt Role:** {{catchit_role}}
- **Primary Truth:** {{primary_truth}}

## UI Behavior
- **Visible Elements:** {{visible_elements}}
- **Suppressed Elements:** {{suppressed_elements}}
- **Information Density:** {{information_density}}
- **Tone:** {{tone}}
- **Visual Consequence:** {{visual_consequence}}

## Boundaries
- **Must Not Mean:** {{must_not_mean}}
- **Kill Criteria:** {{kill_criteria}}

## Notes
- {{notes}}

