// script.js – Manages CatchIt prototype interactions and state

// Define the initial application state
const appState = {
  view: 'wizard', // wizard | comparison | timeline | map | zen
  stateColor: 'blue', // blue | green | yellow | orange | red
  wizardIndex: 0,
  wizardAnswers: {},
  selectedOption: null,
  timelineSteps: [],
};

// Define the wizard questions and options. Each entry carries a key to store the answer.
const wizardSteps = [
  {
    key: 'forWhom',
    question: 'Für wen ist diese Fahrt?',
    options: ['Für mich', 'Für jemand anders'],
  },
  {
    key: 'home1',
    question: 'Wo ist dein Zuhause?',
    options: ['Zuhause', 'Arbeit', 'Schule', 'Andere'],
  },
  {
    key: 'addHome',
    question: 'Noch eine Heimat‑Haltestelle hinzufügen?',
    options: ['Ja', 'Nein'],
  },
  {
    key: 'places',
    question: 'Gibt es wichtige Orte?',
    options: ['Keine', 'Schule', 'Sport', 'Freunde'],
  },
  {
    key: 'helpLevel',
    question: 'Welcher Hilfegrad passt zu dir?',
    options: ['Einfach', 'Standard', 'Kompakt'],
  },
  {
    key: 'audio',
    question: 'Sollen Audio‑Hinweise aktiviert sein?',
    options: ['Ja', 'Nein'],
  },
  {
    key: 'summary',
    question: 'Zusammenfassung',
    options: [], // summary slide
  },
];

// Journey option prototypes for the comparison screen
const journeyOptions = [
  {
    id: 1,
    title: 'Bestes Angebot',
    details: 'Schnellste Verbindung in etwa 30 Minuten',
  },
  {
    id: 2,
    title: 'Reserviert',
    details: 'Komfortabler Weg in etwa 35 Minuten',
  },
  {
    id: 3,
    title: 'Fallback',
    details: 'Robuster Plan in etwa 45 Minuten',
  },
];

// Utility: update clock every second
function updateClock() {
  const clockElement = document.getElementById('clock');
  const now = new Date();
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  clockElement.textContent = `${hours}:${minutes}`;
}
setInterval(updateClock, 1000);
updateClock();

// Change background color class based on stateColor
function applyStateColor() {
  const phone = document.getElementById('phone');
  phone.classList.remove(
    'state-blue',
    'state-green',
    'state-yellow',
    'state-orange',
    'state-red',
  );
  phone.classList.add(`state-${appState.stateColor}`);
}

// Render the wizard UI
function renderWizard() {
  appState.view = 'wizard';
  applyStateColor();
  const main = document.getElementById('main');
  main.innerHTML = '';

  const container = document.createElement('div');
  container.className = 'wizard-container';

  // Get the current wizard step
  const step = wizardSteps[appState.wizardIndex];
  // Question
  const questionEl = document.createElement('div');
  questionEl.className = 'wizard-question';
  questionEl.textContent = step.question;
  container.appendChild(questionEl);

  // Options or summary
  if (step.options && step.options.length > 0) {
    const optionsContainer = document.createElement('div');
    optionsContainer.className = 'wizard-options';
    step.options.forEach((opt) => {
      const optionEl = document.createElement('div');
      optionEl.className = 'wizard-option';
      optionEl.textContent = opt;
      optionEl.addEventListener('click', () => {
        // store answer and highlight selected
        appState.wizardAnswers[step.key] = opt;
        // visually mark active option
        document
          .querySelectorAll('.wizard-option')
          .forEach((el) => el.classList.remove('active'));
        optionEl.classList.add('active');
      });
      optionsContainer.appendChild(optionEl);
    });
    container.appendChild(optionsContainer);
  } else {
    // Summary slide
    const summaryEl = document.createElement('div');
    summaryEl.style.textAlign = 'left';
    summaryEl.style.fontSize = '0.95rem';
    summaryEl.style.lineHeight = '1.4';
    summaryEl.innerHTML =
      '<strong>Deine Angaben:</strong><br>' +
      Object.keys(appState.wizardAnswers)
        .map((key) => {
          const label =
            key === 'forWhom'
              ? 'Für wen'
              : key === 'home1'
              ? 'Zuhause'
              : key === 'addHome'
              ? 'Weitere Heimat'
              : key === 'places'
              ? 'Wichtige Orte'
              : key === 'helpLevel'
              ? 'Hilfegrad'
              : key === 'audio'
              ? 'Audio'
              : key;
          return `${label}: ${appState.wizardAnswers[key] || '-'}`;
        })
        .join('<br>');
    container.appendChild(summaryEl);
  }

  // Navigation buttons
  const nav = document.createElement('div');
  nav.className = 'wizard-nav';
  const prevBtn = document.createElement('button');
  prevBtn.textContent = 'Zurück';
  prevBtn.disabled = appState.wizardIndex === 0;
  prevBtn.addEventListener('click', () => {
    appState.wizardIndex = Math.max(0, appState.wizardIndex - 1);
    renderWizard();
  });
  const nextBtn = document.createElement('button');
  nextBtn.textContent =
    appState.wizardIndex < wizardSteps.length - 1 ? 'Weiter' : 'Fertig';
  nextBtn.addEventListener('click', () => {
    // On summary slide, finish wizard
    if (appState.wizardIndex === wizardSteps.length - 1) {
      // Start comparison
      renderComparison();
    } else {
      appState.wizardIndex += 1;
      renderWizard();
    }
  });
  nav.appendChild(prevBtn);
  nav.appendChild(nextBtn);
  container.appendChild(nav);

  // Progress indicator (dots)
  const progress = document.createElement('div');
  progress.className = 'progress-indicator';
  wizardSteps.forEach((_, idx) => {
    const dot = document.createElement('div');
    dot.className = 'dot';
    if (idx === appState.wizardIndex) dot.classList.add('active');
    progress.appendChild(dot);
  });
  container.appendChild(progress);

  main.appendChild(container);
}

// Render comparison view with journey options
function renderComparison() {
  appState.view = 'comparison';
  appState.stateColor = 'blue';
  applyStateColor();
  const main = document.getElementById('main');
  main.innerHTML = '';
  const container = document.createElement('div');
  container.className = 'comparison-container';
  // Title
  const heading = document.createElement('h2');
  heading.textContent = 'Wähle deine Fahrt';
  heading.style.marginBottom = '16px';
  container.appendChild(heading);
  // Cards
  journeyOptions.forEach((opt) => {
    const card = document.createElement('div');
    card.className = 'option-card';
    card.dataset.optionId = opt.id;
    const titleEl = document.createElement('div');
    titleEl.className = 'option-title';
    titleEl.textContent = opt.title;
    const detailsEl = document.createElement('div');
    detailsEl.className = 'option-details';
    detailsEl.textContent = opt.details;
    card.appendChild(titleEl);
    card.appendChild(detailsEl);
    card.addEventListener('click', () => {
      appState.selectedOption = opt;
      // highlight selection
      document
        .querySelectorAll('.option-card')
        .forEach((c) => c.classList.remove('selected'));
      card.classList.add('selected');
    });
    container.appendChild(card);
  });
  // Nav
  const nav = document.createElement('div');
  nav.className = 'comparison-nav';
  const backBtn = document.createElement('button');
  backBtn.textContent = 'Zurück';
  backBtn.addEventListener('click', () => {
    // return to wizard summary
    appState.wizardIndex = wizardSteps.length - 1;
    renderWizard();
  });
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Weiter';
  nextBtn.addEventListener('click', () => {
    if (!appState.selectedOption) {
      alert('Bitte wähle eine Option aus.');
      return;
    }
    buildTimelineFromOption(appState.selectedOption);
    renderTimeline();
  });
  nav.appendChild(backBtn);
  nav.appendChild(nextBtn);
  container.appendChild(nav);
  main.appendChild(container);
}

// Build timeline steps based on selected journey (dummy for now)
function buildTimelineFromOption(option) {
  // Simulate steps: get durations from details (approx minutes) or fallback
  // We'll parse numbers in the details string if present
  let minutes = 30;
  const match = option.details.match(/(\d+)\s*Min/);
  if (match) minutes = parseInt(match[1]);
  // We'll split into 3 steps: 20% walk to stop, 60% ride, 20% walk to destination
  const walk1 = Math.max(1, Math.round(minutes * 0.2));
  const ride = Math.max(1, Math.round(minutes * 0.6));
  const walk2 = Math.max(1, minutes - walk1 - ride);
  appState.timelineSteps = [
    { label: 'Zum Startpunkt gehen', duration: walk1 },
    { label: 'Fahrt', duration: ride },
    { label: 'Zum Ziel gehen', duration: walk2 },
  ];
}

// Render timeline view with countdown and steps
function renderTimeline() {
  appState.view = 'timeline';
  appState.stateColor = 'green';
  applyStateColor();
  const main = document.getElementById('main');
  main.innerHTML = '';
  const container = document.createElement('div');
  container.className = 'timeline-container';
  // Countdown ring element
  const ringContainer = document.createElement('div');
  ringContainer.className = 'countdown-ring';
  // Create SVG ring
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  const size = 120;
  const strokeWidth = 8;
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  const circleBg = document.createElementNS(svgNS, 'circle');
  const radius = (size - strokeWidth) / 2;
  circleBg.setAttribute('cx', size / 2);
  circleBg.setAttribute('cy', size / 2);
  circleBg.setAttribute('r', radius);
  circleBg.setAttribute('stroke-width', strokeWidth);
  circleBg.setAttribute('stroke', 'rgba(255, 255, 255, 0.3)');
  circleBg.setAttribute('fill', 'none');
  svg.appendChild(circleBg);
  const circleProgress = document.createElementNS(svgNS, 'circle');
  circleProgress.setAttribute('cx', size / 2);
  circleProgress.setAttribute('cy', size / 2);
  circleProgress.setAttribute('r', radius);
  circleProgress.setAttribute('stroke-width', strokeWidth);
  circleProgress.setAttribute('stroke', '#fff');
  circleProgress.setAttribute('fill', 'none');
  circleProgress.setAttribute('stroke-linecap', 'round');
  circleProgress.setAttribute('transform', `rotate(-90 ${size / 2} ${size / 2})`);
  const circumference = 2 * Math.PI * radius;
  circleProgress.setAttribute('stroke-dasharray', `${circumference}`);
  circleProgress.setAttribute('stroke-dashoffset', `${circumference}`);
  svg.appendChild(circleProgress);
  ringContainer.appendChild(svg);
  // countdown text
  const countdownText = document.createElement('div');
  countdownText.style.position = 'absolute';
  countdownText.style.top = '50%';
  countdownText.style.left = '50%';
  countdownText.style.transform = 'translate(-50%, -50%)';
  countdownText.style.fontSize = '1.4rem';
  countdownText.style.fontWeight = '600';
  countdownText.id = 'countdown-label';
  ringContainer.style.position = 'relative';
  ringContainer.appendChild(countdownText);
  container.appendChild(ringContainer);
  // Steps list
  const list = document.createElement('ul');
  list.className = 'timeline-list';
  appState.timelineSteps.forEach((step) => {
    const item = document.createElement('li');
    item.className = 'timeline-item';
    const marker = document.createElement('div');
    marker.className = 'step-marker';
    const content = document.createElement('div');
    content.className = 'step-content';
    content.textContent = `${step.label} (${step.duration} Min)`;
    item.appendChild(marker);
    item.appendChild(content);
    list.appendChild(item);
  });
  container.appendChild(list);
  // Nav
  const nav = document.createElement('div');
  nav.className = 'timeline-nav';
  const mapBtn = document.createElement('button');
  mapBtn.textContent = 'Karte';
  mapBtn.addEventListener('click', () => {
    renderMap();
  });
  const optionsBtn = document.createElement('button');
  optionsBtn.textContent = 'Andere Option';
  optionsBtn.addEventListener('click', () => {
    renderComparison();
  });
  nav.appendChild(mapBtn);
  nav.appendChild(optionsBtn);
  container.appendChild(nav);
  main.appendChild(container);
  // Start countdown timer
  startCountdown(circleProgress, circumference, countdownText);
}

// Start countdown timer and update circle progress
function startCountdown(circleElem, circumference, labelElem) {
  // total minutes = sum of durations
  const totalMin = appState.timelineSteps.reduce((sum, s) => sum + s.duration, 0);
  let remainingSec = totalMin * 60;
  function update() {
    if (appState.view !== 'timeline') return;
    const offset = (circumference * (remainingSec / (totalMin * 60)));
    circleElem.setAttribute(
      'stroke-dashoffset',
      `${circumference - offset}`,
    );
    const minutes = Math.floor(remainingSec / 60);
    const seconds = remainingSec % 60;
    labelElem.textContent = `${minutes}:${seconds
      .toString()
      .padStart(2, '0')}`;
    if (remainingSec > 0) {
      remainingSec -= 1;
      setTimeout(update, 1000);
    } else {
      // End reached: mark state as orange or red
      appState.stateColor = 'orange';
      applyStateColor();
    }
  }
  update();
}

// Render the map view
function renderMap() {
  appState.view = 'map';
  // keep previous state color (likely green/yellow/orange)
  applyStateColor();
  const main = document.getElementById('main');
  main.innerHTML = '';
  const container = document.createElement('div');
  container.className = 'map-container';
  // Placeholder for map; in a real app this would integrate a mapping library
  const placeholder = document.createElement('div');
  placeholder.className = 'map-placeholder';
  placeholder.textContent = 'Karte des Fußwegs zur Haltestelle';
  container.appendChild(placeholder);
  // Overlay with countdown label (copy from timeline)
  const overlay = document.createElement('div');
  overlay.className = 'map-overlay';
  // copy current countdown text
  const timelineLabel = document.getElementById('countdown-label');
  overlay.textContent = timelineLabel ? timelineLabel.textContent : '';
  container.appendChild(overlay);
  // Nav
  const nav = document.createElement('div');
  nav.className = 'map-nav';
  const backBtn = document.createElement('button');
  backBtn.textContent = 'Zurück';
  backBtn.addEventListener('click', () => {
    renderTimeline();
  });
  nav.appendChild(backBtn);
  // Optionally, we can allow to finish journey from map
  const finishBtn = document.createElement('button');
  finishBtn.textContent = 'Abbrechen';
  finishBtn.addEventListener('click', () => {
    // return to Zen state
    renderZen();
  });
  nav.appendChild(finishBtn);
  container.appendChild(nav);
  main.appendChild(container);
}

// Render the Zen (idle) state: show summary and options to plan a new trip
function renderZen() {
  appState.view = 'zen';
  appState.stateColor = 'blue';
  applyStateColor();
  const main = document.getElementById('main');
  main.innerHTML = '';
  const container = document.createElement('div');
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.justifyContent = 'center';
  container.style.alignItems = 'center';
  container.style.height = '100%';
  // Summary if a plan exists
  if (appState.timelineSteps.length > 0) {
    const summaryCard = document.createElement('div');
    summaryCard.className = 'option-card';
    summaryCard.style.textAlign = 'center';
    summaryCard.style.maxWidth = '280px';
    summaryCard.innerHTML =
      `<div class="option-title">Aktive Fahrt</div>` +
      `<div class="option-details">${appState.selectedOption?.title || ''} &nbsp; • &nbsp; ${appState.selectedOption?.details || ''}</div>`;
    const continueBtn = document.createElement('button');
    continueBtn.textContent = 'Fortsetzen';
    continueBtn.style.marginTop = '12px';
    continueBtn.style.padding = '8px 12px';
    continueBtn.style.borderRadius = 'var(--border-radius)';
    continueBtn.style.border = 'none';
    continueBtn.style.backgroundColor = 'var(--card-bg)';
    continueBtn.style.color = 'var(--text-dark)';
    continueBtn.addEventListener('click', () => {
      renderTimeline();
    });
    summaryCard.appendChild(continueBtn);
    container.appendChild(summaryCard);
  }
  // Button to start a new plan
  const newPlanBtn = document.createElement('button');
  newPlanBtn.textContent = 'Neue Fahrt planen';
  newPlanBtn.style.padding = '12px 16px';
  newPlanBtn.style.borderRadius = 'var(--border-radius)';
  newPlanBtn.style.border = 'none';
  newPlanBtn.style.backgroundColor = 'var(--card-bg)';
  newPlanBtn.style.color = 'var(--text-dark)';
  newPlanBtn.style.marginTop = '24px';
  newPlanBtn.addEventListener('click', () => {
    // Reset wizard
    appState.wizardIndex = 0;
    appState.wizardAnswers = {};
    appState.selectedOption = null;
    appState.timelineSteps = [];
    renderWizard();
  });
  container.appendChild(newPlanBtn);
  main.appendChild(container);
}

// Display tutorial overlay on first visit
function showTutorial() {
  const overlay = document.getElementById('tutorial-overlay');
  if (!overlay) return;
  const closed = localStorage.getItem('catchitTutorialSeen');
  if (closed) return;
  overlay.classList.remove('hidden');
  document.getElementById('tutorial-close').addEventListener('click', () => {
    overlay.classList.add('hidden');
    localStorage.setItem('catchitTutorialSeen', 'true');
  });
}

// Initialise app
function init() {
  // Listen for ESC key to exit map or timeline quickly (optional)
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') {
      if (appState.view === 'map') {
        renderTimeline();
      } else if (appState.view === 'timeline') {
        renderZen();
      }
    }
  });
  // Start with Zen idle state
  renderZen();
  showTutorial();
}

// Kick off the application once DOM is ready
document.addEventListener('DOMContentLoaded', init);