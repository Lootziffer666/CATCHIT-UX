# CatchIt Design – Paketübersicht

## Zweck je Teil

| Teil | Fokus | Zielgruppe |
|---|---|---|
| 1 | Produktkern, Zustandslogik, Trust/ND/Privacy | Produkt, UX, Strategie |
| 2 | Informationsarchitektur, Screen-System, Flowlogik | UX, IA, Screen-Konzept |
| 3 | Mockups, Figma-Screens, Prototype, Präsentation | Design, Figma, Stakeholder |
| 4 | Tokens, Properties, Component Contracts, Variants | Design System, Figma-Architektur |
| 5 | Compose-/Android-Übersetzung | Android, Compose, Architektur |

## Schnellzugriff

- Wenn es um **Was ist CatchIt eigentlich?** geht → Teil 1
- Wenn es um **Welche Screens und Zustände braucht CatchIt?** geht → Teil 2
- Wenn es um **Wie baue/präsentiere ich die Mockups?** geht → Teil 3
- Wenn es um **Wie strukturiere ich Figma-Komponenten und Tokens?** geht → Teil 4
- Wenn es um **Wie übersetze ich das in Android/Compose?** geht → Teil 5
