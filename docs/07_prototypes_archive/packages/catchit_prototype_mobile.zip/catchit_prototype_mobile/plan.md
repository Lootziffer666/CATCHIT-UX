# Interaktiver CatchIt‑Prototyp – Zustand & Layoutfamilien

Dieser Entwurf zeigt, wie sich das Prinzip der **„harten Konstanten über alle Frames“** (Gerätekontainer, Navigations‑Chrome und Entscheidungsanker) auf die Benutzeroberfläche einer Mobilitäts‑App anwenden lässt. Der Prototyp folgt der modularen Architektur aus dem **CATCHIT**‑Kern, in dem der eigentliche Mobilitäts‑Stack und das Zustands/Scene‑System liegen, und fügt die spätere **Cathy**‑Ebene als semantischen UI‑Layer obenauf. Er illustriert eine mögliche Evolution vom offenen, explorativen **Planungsmodus** zur dichten, sequentiellen **Ausführungs‑Vertikale**.

## Kernzustände

Die Anwendung besteht aus fünf Zuständen, die jeweils eigene Layoutfamilien besitzen, aber durch konstante Elemente verbunden sind:

1. **Zen‑Übersicht** (Statusfokus):
   - Funktion: Kurze Übersicht der eingeplanten Vorhaben („Luke abholen“, „Ergo‑Therapie“ …) mit ruhiger Stimmung.  
   - Layout: Vollflächiger Gerätekontainer mit frei schwebendem Entscheidungsanker oben links. Die Liste der Termine ist komprimiert; sie zeigt nur Titel, Zeiten und einfache Icons. Ein einzelner Knopf „Planen“ führt in den Wizard.
   - Regeln: Der Anker bleibt sichtbar, es gibt keinen erklärenden Satz; der Raum ist luftig und erleichtert schnelles Erfassen.

2. **Planungs‑Wizard – Teil 1** (erste Verdichtung):
   - Funktion: Sammeln der wesentlichen Informationen (z. B. Ort).  
   - Layout: Eine horizontale Linie symbolisiert die „Planungsachse“. Kreise (Punkte) dienen als kognitive Stützen für einzelne Schritte. Der aktive Punkt ist blau und liegt auf der Linie; abgeschlossene Schritte werden ausgefüllt.  
   - Komponenten: Entscheidungsanker (Kreis), Eingabefeld „Was liegt an?“ für den Ort, Button „Weiter“.  
   - Bewegungsregel: Die horizontale Planung erstreckt sich von links nach rechts; der Punkt bewegt sich mit jeder Eingabe sanft weiter.

3. **Planungs‑Wizard – Teil 2** (Umverteilung der Priorität):
   - Funktion: Auswahl von Uhrzeit und Datum.  
   - Layout: Gleiches horizontales Grid; der erste Punkt ist ausgefüllt, der zweite aktiv. Zwei Eingabefelder („Uhrzeit“, „Datum“) stehen nebeneinander; unter ihnen wird optional eine Wochentagswahl angezeigt.  
   - Regeln: Der Entscheidungsanker bleibt identisch; Bewegungen erfolgen mit Easing‑Funktionen. Sobald die Informationen vorliegen, erscheint ein Button „Fertig“.

4. **Planübersicht & Vergleich** (Kartenfokus):
   - Funktion: Zusammenfassung der geplanten Schritte und ggf. Vergleich von Alternativen.  
   - Layout: Kompakte Kartendarstellung in der Gerätekontainer‑Mitte; darunter eine Liste der Schritte.  
   - Regeln: Der Anker bleibt; die horizontale Planung verschwindet zugunsten einer neutralen Karte/Listenansicht. Der Benutzer kann den Plan bestätigen („Start“). Bei mehreren Varianten könnten mehrere Karten nebeneinander stehen.

5. **Ausführungs‑Vertikale & Recovery** (sekundäre Zustände):
   - Funktion: Nach der Bestätigung wechselt die Oberfläche in eine vertikale Zeitleiste. Sie folgt der modellierten Journey und dem Zeit/Scene‑System des CATCHIT‑Kerns.  
   - Layout: Die Zeitleiste nutzt die gesamte Gerätekontainer‑Höhe. Oben sitzt der Entscheidungsanker jetzt als **Countdown‑Timer** (weiß/gold), der die verbleibende Zeit bis zum nächsten Schritt anzeigt. Darunter folgen Schrittkarten mit Nummerierung (z. B. „17“ für Linie 17), Titeln und Zeitangaben.  
   - Regeln: Verdichtung nach oben – vergangene Schritte verkleinern sich und verschwinden; kommende Schritte erscheinen unten. Soft‑Easing animiert den Übergang. Ein Steuerpanel am Fuß erlaubt Pausieren, Nachjustieren oder Abbrechen. Im Recovery‑Modus kann bei Störungen (z. B. Verspätungen) ein seitlicher Horizontal‑Schieber eingeblendet werden, um eine neue Planung einzuleiten.

## Informationshierarchie

- **Anker (Kreis/Timer):** permanent sichtbar; dient als kognitiver Bezugspunkt und Sicherheitsindikator. In der Ausführung zeigt er auch die verbleibende Zeit.
- **Navigation & Chrome:** zurück‑ und Menü‑Schaltflächen bleiben immer am gleichen Ort, um Orientierung zu geben. Die Farbgebung ist neutral, mit goldener Hervorhebung für den Sicherheitszustand.
- **Horizontale Elemente:** stehen für Planung und Entscheidungsvorbereitung. Der Nutzer kann mehrere Optionen bedenken, bevor er sich festlegt.  
- **Vertikale Elemente:** zeigen den tatsächlichen Ablauf – sequentiell, dicht, von oben nach unten. Die vertikale Zeitleiste spiegelt den Live‑Status wider.

## Technischer Aufbau

Die Dateien des Prototyps:

- **index.html** – definiert alle UI‑Zustände in getrennten `<section>`‑Containern. Die Sichtbarkeit wird mit Hilfe von CSS‑Klassen gesteuert.  
- **styles.css** – enthält das Layout mit flexiblen Reihen, neutralen Grautönen und subtilen Akzentfarben. Der Entscheidungsanker ist ein runder Div mit Rand; im Ausführungsmodus wird der Rest‑Countdown per Schrift angezeigt.  
- **script.js** – implementiert einfache Navigation zwischen Zuständen und einen exemplarischen Countdown‑Timer. Bei echten Daten würde der Timer an das CATCHIT‑State‑System angebunden.  
- **plan.md** – diese Dokumentation; sie erklärt die Zustände, die Informationshierarchie und die Übernahme der „harten Konstanten“.

Der Prototyp ist bewusst reduziert und nutzt HTML/CSS/JS ohne Framework. Er orientiert sich an dem modularen Aufbau der CATCHIT‑Repositorys und lässt sich schrittweise erweitern – z. B. um echte Provider‑Daten, Lokalisierung oder Accessibility‑Features für ND‑Kinder.