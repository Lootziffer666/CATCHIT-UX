// Steuerung der Zustandswechsel und exemplarische Daten

// Hilfsfunktion zum Umschalten der sichtbaren Sektion
function showSection(id) {
  document.querySelectorAll('.stage').forEach(sec => sec.classList.remove('visible'));
  document.getElementById(id).classList.add('visible');
}

// Start‑Button in der Zen‑Übersicht
document.getElementById('startPlanning').addEventListener('click', () => {
  showSection('plan1');
});

// Weiter zur Zeit/Datum‑Eingabe
document.getElementById('toPlan2').addEventListener('click', () => {
  const location = document.getElementById('locationInput').value.trim();
  if (!location) {
    alert('Bitte gib einen Ort oder eine Aktivität ein.');
    return;
  }
  // Speichern als temporäres Attribut
  document.getElementById('plan1').dataset.location = location;
  showSection('plan2');
});

// Fertig – Zusammenfassung generieren
document.getElementById('toSummary').addEventListener('click', () => {
  const time = document.getElementById('timeInput').value;
  const date = document.getElementById('dateInput').value;
  if (!time || !date) {
    alert('Bitte wähle eine Uhrzeit und ein Datum.');
    return;
  }
  const location = document.getElementById('plan1').dataset.location;
  // Füge Eintrag zur Zusammenfassung hinzu
  const summaryList = document.getElementById('summaryList');
  summaryList.innerHTML = '';
  const li = document.createElement('li');
  li.textContent = `${location} – ${date} ${time}`;
  summaryList.appendChild(li);
  showSection('summary');
});

// Start der Ausführung
document.getElementById('executePlan').addEventListener('click', () => {
  // Beispielhafte Schritte (in echter App würden diese aus dem Kern kommen)
  const steps = [
    { number: '17', title: 'Luke abholen', info: '09:31 – 09:42 · Linie 430' },
    { number: '   ', title: 'Ergo‑Therapie', info: '10:30 Uhr' },
    { number: '1', title: 'Zurück zur Kita', info: 'Bus 1 · Fußweg' },
    { number: '   ', title: 'Nach Hause', info: 'Fußweg' }
  ];
  const timeline = document.getElementById('timeline');
  timeline.innerHTML = '';
  steps.forEach(step => {
    const div = document.createElement('div');
    div.className = 'step';
    const num = document.createElement('div');
    num.className = 'number';
    num.textContent = step.number.trim() || '•';
    const info = document.createElement('div');
    info.className = 'step-info';
    const h3 = document.createElement('h3');
    h3.textContent = step.title;
    const times = document.createElement('div');
    times.className = 'times';
    times.textContent = step.info;
    info.appendChild(h3);
    info.appendChild(times);
    div.appendChild(num);
    div.appendChild(info);
    timeline.appendChild(div);
  });
  showSection('execute');
  startCountdown(15); // 15 Minuten exemplarisch
});

// Countdown‑Timer (minutenbasierter Timer mit schnellerem Ablauf für Demo)
let countdownInterval;
function startCountdown(minutes) {
  clearInterval(countdownInterval);
  let totalSeconds = minutes * 60;
  const countdownElem = document.getElementById('countdown');
  updateCountdown();
  countdownInterval = setInterval(() => {
    totalSeconds--;
    if (totalSeconds <= 0) {
      clearInterval(countdownInterval);
    }
    updateCountdown();
  }, 1000); // jede Sekunde herunterzählen
  function updateCountdown() {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    countdownElem.textContent = `${m}:${s.toString().padStart(2, '0')}`;
  }
}

// Steuerpanel – derzeit nur Platzhalter ohne Logik
document.getElementById('pauseBtn').addEventListener('click', () => {
  // In echter App würde der Timer pausiert werden
  alert('Pause (nicht implementiert)');
});
document.getElementById('cancelBtn').addEventListener('click', () => {
  // Zurück zur Zen‑Übersicht oder Recovery
  clearInterval(countdownInterval);
  showSection('zen');
});
document.getElementById('plusBtn').addEventListener('click', () => {
  alert('Plus (nicht implementiert)');
});
document.getElementById('minusBtn').addEventListener('click', () => {
  alert('Minus (nicht implementiert)');
});