/*
  CATCHIT Redesign – JavaScript

  Dieses Skript implementiert die interaktive Logik für die neu gestaltete
  CatchIt‑Benutzeroberfläche. Es folgt den Prinzipien der horizontalen
  Planung mit Kreisen (Plan‑Phase), der vertikalen Ausführung (Go‑Phase)
  und dem Recovery‑Modus. Alle Zustände werden in localStorage persistiert,
  sodass sie Seitenwechsel überstehen.
*/

(function() {
  /**
   * Utility: Speichert den Plan (Array von Aufgaben) im localStorage.
   * @param {Array} plan
   */
  function savePlan(plan) {
    localStorage.setItem('catchit_plan', JSON.stringify(plan));
  }

  /**
   * Utility: Lädt den Plan aus localStorage. Gibt leeres Array zurück,
   * wenn noch keiner vorhanden ist.
   * @returns {Array}
   */
  function loadPlan() {
    const raw = localStorage.getItem('catchit_plan');
    return raw ? JSON.parse(raw) : [];
  }

  /**
   * Berechnet die Minuten bis zu einem Zielzeitpunkt.
   * @param {string} dateStr – Datum im Format YYYY-MM-DD
   * @param {string} timeStr – Uhrzeit im Format HH:MM
   * @returns {number} Differenz in Minuten (>=0)
   */
  function minutesUntil(dateStr, timeStr) {
    const now = new Date();
    const target = new Date(dateStr + 'T' + timeStr);
    const diff = Math.max(0, Math.round((target - now) / 60000));
    return diff;
  }

  /**
   * Fügt zu einer Uhrzeit (HH:MM) eine Anzahl von Minuten hinzu.
   * @param {string} timeStr
   * @param {number} minutes
   * @returns {string} Neue Uhrzeit HH:MM (24h)
   */
  function addMinutes(timeStr, minutes) {
    const [h, m] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(h, m + minutes);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  /**
   * Initialisiert die Planungsseite (horizontaler Wizard). Baut die
   * Aufgabenleiste auf, zeigt bei Auswahl ein Formular an und speichert
   * die ausgewählten Aufgaben.
   */
  function initPlanning() {
    const planBar = document.querySelector('.plan-bar');
    const form = document.querySelector('#taskForm');
    const taskSelect = document.querySelector('#taskType');
    const descriptionContainer = document.querySelector('#descriptionContainer');
    const descriptionInput = document.querySelector('#description');
    const dateInput = document.querySelector('#taskDate');
    const timeInput = document.querySelector('#taskTime');
    const finishButton = document.querySelector('#finishPlan');

    // Definition der verfügbaren Aufgabentypen
    const tasks = [
      { id: 'child', label: 'Kind abholen' },
      { id: 'home', label: 'Nach Hause' },
      { id: 'therapy', label: 'Therapie' },
      { id: 'shop', label: 'Einkaufen' },
      { id: 'custom', label: 'Andere' },
    ];

    // Initialisierung des Planbars mit Schritten
    const plan = loadPlan();
    tasks.forEach((t, index) => {
      const step = document.createElement('div');
      step.className = 'step';
      if (plan.some(p => p.id === t.id)) {
        step.classList.add('completed');
      }
      step.dataset.taskId = t.id;
      const circle = document.createElement('div');
      circle.className = 'circle';
      circle.textContent = index + 1;
      const label = document.createElement('label');
      label.textContent = t.label;
      step.appendChild(circle);
      step.appendChild(label);
      planBar.appendChild(step);
    });

    // Klickhandler für Schritte
    planBar.addEventListener('click', (e) => {
      const target = e.target.closest('.step');
      if (!target) return;
      const { taskId } = target.dataset;
      // Markiere aktiven Schritt
      Array.from(planBar.children).forEach(s => s.classList.remove('active'));
      target.classList.add('active');
      form.classList.remove('hidden');
      // Setze Formulardaten je nach Aufgabentyp
      taskSelect.value = taskId;
      if (taskId === 'custom') {
        descriptionContainer.classList.remove('hidden');
      } else {
        descriptionContainer.classList.add('hidden');
      }
    });

    // Formularabsendung
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const taskId = taskSelect.value;
      const description = descriptionInput.value.trim();
      const date = dateInput.value;
      const time = timeInput.value;
      if (!taskId || !date || !time) return;
      const selected = tasks.find(t => t.id === taskId);
      const plan = loadPlan();
      // Überprüfe, ob dieser Aufgabentyp bereits existiert (unique)
      const existingIndex = plan.findIndex(p => p.id === taskId);
      const entry = {
        id: taskId,
        label: selected.label,
        description: taskId === 'custom' ? description : '',
        date: date,
        time: time,
      };
      if (existingIndex >= 0) {
        plan[existingIndex] = entry;
      } else {
        plan.push(entry);
      }
      savePlan(plan);
      // Markiere Schritt als completed
      const step = planBar.querySelector(`.step[data-task-id="${taskId}"]`);
      if (step) {
        step.classList.remove('active');
        step.classList.add('completed');
      }
      // Formular zurücksetzen
      form.classList.add('hidden');
      descriptionInput.value = '';
      // Wenn alle ausgewählten Aufgaben eingetragen sind, kann der Plan fertiggestellt werden
      finishButton.disabled = plan.length === 0;
    });

    // Standarddatum auf heute setzen
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
    // Deaktiviere Finish, wenn kein Plan existiert
    finishButton.disabled = loadPlan().length === 0;
    finishButton.addEventListener('click', () => {
      window.location.href = 'timeline.html';
    });
  }

  /**
   * Initialisiert die Timeline‑Seite. Baut die vertikale Timeline basierend auf dem
   * gespeicherten Plan auf, aktiviert einen Countdown und erlaubt das Öffnen des
   * Recovery‑Modus.
   */
  function initTimeline() {
    const timelineContainer = document.querySelector('.timeline');
    const ring = document.querySelector('.ring');
    const plan = loadPlan().sort((a, b) => {
      // Sortiere nach Datum und Uhrzeit
      if (a.date === b.date) {
        return a.time.localeCompare(b.time);
      }
      return a.date.localeCompare(b.date);
    });
    if (plan.length === 0) {
      timelineContainer.innerHTML = '<p>Kein Plan gefunden. Bitte erst eine Planung durchführen.</p>';
      return;
    }
    // Baue Timeline
    plan.forEach((entry, index) => {
      const item = document.createElement('div');
      item.className = 'item';
      const bullet = document.createElement('div');
      bullet.className = 'bullet';
      // Markiere erledigte Einträge (Vergangenheit)
      const minutes = minutesUntil(entry.date, entry.time);
      if (minutes <= 0) {
        bullet.classList.add('completed');
      }
      bullet.textContent = index + 1;
      const details = document.createElement('div');
      details.className = 'details';
      const timeEl = document.createElement('div');
      timeEl.className = 'time';
      timeEl.textContent = `${entry.time} Uhr`;
      const labelEl = document.createElement('div');
      labelEl.className = 'label';
      labelEl.textContent = entry.label + (entry.description ? ` – ${entry.description}` : '');
      details.appendChild(timeEl);
      details.appendChild(labelEl);
      item.appendChild(bullet);
      item.appendChild(details);
      timelineContainer.appendChild(item);
    });
    // Countdown starten: nächster Eintrag im Plan
    const now = new Date();
    let nextEntry = plan.find(e => new Date(e.date + 'T' + e.time) > now);
    if (nextEntry) {
      const updateCountdown = () => {
        const diff = minutesUntil(nextEntry.date, nextEntry.time);
        ring.textContent = diff + 'm';
        const percentage = Math.max(0, Math.min(1, diff / 60));
        ring.style.setProperty('--ring-progress', (1 - percentage) * 100 + '%');
        if (diff > 0) {
          setTimeout(updateCountdown, 60000);
        }
      };
      ring.dataset.mode = 'countdown';
      updateCountdown();
    } else {
      ring.textContent = '–';
    }
    // Recovery Button, falls vorhanden
    const recoveryBtn = document.querySelector('#recoveryBtn');
    if (recoveryBtn) {
      recoveryBtn.addEventListener('click', () => {
        window.location.href = 'recovery.html';
      });
    }
  }

  /**
   * Initialisiert die Recovery‑Seite. Zeigt Optionen zur Neuplanung,
   * Neuberechnung oder Hilfe.
   */
  function initRecovery() {
    const retryBtn = document.querySelector('#retryPlan');
    const newPlanBtn = document.querySelector('#newPlan');
    const helpBtn = document.querySelector('#callHelp');
    if (retryBtn) retryBtn.addEventListener('click', () => {
      window.location.href = 'timeline.html';
    });
    if (newPlanBtn) newPlanBtn.addEventListener('click', () => {
      // Lösche Plan und starte neu
      savePlan([]);
      window.location.href = 'index.html';
    });
    if (helpBtn) helpBtn.addEventListener('click', () => {
      alert('Hilfe wird informiert.');
    });
  }

  // Seite anhand ihres body‑Attributs initialisieren
  document.addEventListener('DOMContentLoaded', () => {
    const page = document.body.dataset.page;
    switch (page) {
      case 'planning':
        initPlanning();
        break;
      case 'timeline':
        initTimeline();
        break;
      case 'recovery':
        initRecovery();
        break;
    }
  });
})();