# CatchIt Redesign – UX‑Plan

Dieses Dokument beschreibt die Neuimplementierung der CatchIt‑Benutzeroberfläche nach den im Projekt definierten Prinzipien. Ziel war es, eine eindeutige Trennung zwischen Planung (Plan‑Phase), Ausführung (Go‑Phase) und Recovery zu schaffen und dabei die in den Referenzen beschriebenen Gestaltungsmuster zu respektieren.

## Grundkonzept

CatchIt versteht sich als Entscheidungs‑ und Entlastungssystem, nicht als klassische Navigations‑ oder Transit‑App. Die Benutzeroberfläche soll sicher und beruhigend wirken, sich auf die wesentlichen Aufgaben des Nutzers konzentrieren und den mentalen Aufwand reduzieren. Kernpunkte:

* **Horizontale Planung:** Die Planung erfolgt auf einer waagerechten Linie. Jeder Schritt wird als Kreis dargestellt. Der Nutzer wählt aus vordefinierten Aufgabentypen (z. B. „Kind abholen“, „Nach Hause“, „Therapie“, „Einkaufen“ oder „Andere“). Bei Auswahl eines Schritts öffnet sich ein minimales Formular, in dem Datum und Uhrzeit (und bei benutzerdefinierten Aufgaben eine optionale Beschreibung) angegeben werden. Die Kreise helfen als kognitive Stütze – sie erinnern an die spätere Timeline.
* **Vertikale Ausführung:** Nach dem Abschluss der Planung wird die Abfolge in eine vertikale Timeline überführt. Die Kreise werden zu Haltepunkten entlang einer senkrechten Linie. Ein Ring oben im Header zeigt als Countdown die verbleibende Zeit bis zum nächsten Schritt und füllt sich dabei teilweise mit einer goldenen Fläche, die den Sicherheits‑/Pufferindikator visualisiert.
* **Recovery:** Bei Unterbrechungen oder Störungen kann der Nutzer jederzeit in den Recovery‑Modus wechseln. Dort kann er den Plan fortsetzen, eine Neuplanung starten oder Hilfe anfordern.

## Dateien

| Datei | Zweck |
|------|-------|
| **style.css** | Enthält sämtliche Styles (Farbvariablen, Layouts, Ringe, Planungslinie, Timeline, Buttons). Die Gestaltung bleibt neutral, sanft und gut lesbar auf Smartphones. |
| **script.js** | Implementiert die Interaktivität: Auswahl der Aufgaben, Speicherung im LocalStorage, Übergang zur Timeline, Countdown‑Funktion und Recovery‑Navigation. |
| **index.html** | Planungsscreen (Plan‑Phase). Zeigt die horizontale Aufgabenleiste sowie das Formular zur Eingabe von Datum, Uhrzeit und optionaler Beschreibung. |
| **timeline.html** | Ausführungsscreen (Go‑Phase). Baut die vertikale Timeline auf Basis des gespeicherten Plans auf und zeigt einen Countdown‑Ring. |
| **recovery.html** | Recovery‑Screen. Bietet Optionen zum Fortsetzen, Neuplanen oder Hilfe rufen. |
| **plan.md** | Dieses Dokument. |
| **mobile.html** | Eine für Smartphones optimierte Einzelseiten‑Version, die alle wesentlichen Funktionen (Planen, Ausführen, Recovery) in einem Dokument vereint und Inline‑Styles sowie Inline‑JS nutzt. |

## Nutzung

1. **Planung starten:** Öffnen Sie `index.html`. Die horizontale Leiste zeigt fünf Kreise für unterschiedliche Aufgabenarten. Tippen Sie auf einen Kreis, um ihn zu aktivieren; es erscheint darunter ein Formular. Geben Sie Datum und Uhrzeit an, optional eine Beschreibung. Nach dem Speichern wird der Kreis gefüllt. Sobald mindestens eine Aufgabe hinterlegt ist, kann der Plan in die Ausführung überführt werden (Button „Zur Ausführung“).
2. **Ausführung:** Nach dem Abschluss der Planung führt `timeline.html` die Aufgaben in einer vertikalen Liste auf. Jeder Eintrag zeigt Uhrzeit und Bezeichnung. Oben befindet sich der Ring, der die verbleibenden Minuten bis zur nächsten Aufgabe zählt. Über „Unterbrechung melden“ kann der Recovery‑Modus aufgerufen werden.
3. **Recovery:** In `recovery.html` kann der Nutzer den Plan fortsetzen, eine komplett neue Planung starten oder Hilfe anfordern. Eine neue Planung löscht den bisher gespeicherten Plan.

## Erweiterbarkeit

Diese Version legt die semantischen Grundlagen für CatchIt. Es wurden bewusst keine komplexen Routenvergleiche oder Verkehrsdaten eingebaut, um den Fokus auf die Kernlogik zu legen. Künftige Erweiterungen könnten realistische Verkehrs‑/Fahrplandaten integrieren, zusätzliche Aufgabentypen anbieten oder adaptives Verhalten für spezielle Nutzergruppen (z. B. ND‑Kinder) implementieren. Die klare Trennung der Zustände und die persistente Speicherung erleichtern diese Erweiterungen.