/*
 * CatchIt Prototype Script
 *
 * Dieses Skript implementiert einen simplen Zustandsspeicher und rendert
 * die verschiedenen Ansichten: Zen (Orientierung), Wizard (Planung),
 * Comparison (Alternativen), Execution (Ausführung) und Recovery (Rettung).
 * Die Daten sind fiktiv und dienen dem interaktiven Ausprobieren. Der
 * Fokus liegt auf der Illustration der Flow‑Logik und der Semantik,
 * nicht auf finaler UI oder komplexen Datenmodellen.
 */

document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app');
  const modeIndicator = document.getElementById('mode-indicator');
  const disruptionButton = document.getElementById('simulate-disruption');
  const cathyBubble = document.getElementById('cathy-bubble');

  // Zustand
  let currentState = 'zen';
  let currentPlan = null;
  let currentStepIndex = 0;
  let wizardData = {};

  // Zeige oder verberge Cathy‑Bubble
  function showCathy(show) {
    if (show) {
      cathyBubble.classList.remove('hidden');
    } else {
      cathyBubble.classList.add('hidden');
    }
  }

  // Utility: Set mode indicator text and color
  function setModeIndicator(text, colorVar) {
    modeIndicator.textContent = text;
    if (colorVar) {
      modeIndicator.style.backgroundColor = getComputedStyle(document.documentElement).getPropertyValue(colorVar);
    }
  }

  // Render Zen (orientation) view
  function renderZen() {
    currentState = 'zen';
    setModeIndicator('Zen', '--color-stable');
    disruptionButton.style.display = 'none';
    showCathy(false);
    const html = `
      <div class="card">
        <h2>Zen‑Ansicht</h2>
        <p>Willkommen bei CatchIt. Du hast aktuell noch keinen Plan.</p>
        <p>Erstelle einen neuen Plan, indem du dein Ziel und ein paar einfache Fragen beantwortest.</p>
        <button class="button" id="start-plan">Plan erstellen</button>
      </div>
    `;
    app.innerHTML = html;
    document.getElementById('start-plan').addEventListener('click', () => {
      renderWizard();
    });
  }

  // Render Wizard (planning) view
  function renderWizard() {
    currentState = 'wizard';
    setModeIndicator('Planung', '--color-attentive');
    disruptionButton.style.display = 'none';
    showCathy(false);
    app.innerHTML = '';
    const container = document.createElement('div');
    container.className = 'card';
    container.innerHTML = `
      <h2>Wizard: Dein Vorhaben</h2>
      <div class="wizard-step">
        <label for="destination">Wohin möchtest du?</label>
        <input type="text" id="destination" placeholder="z. B. Hauptbahnhof" required />
      </div>
      <div class="wizard-step">
        <label for="follow-up">Musst du danach noch weiter?</label>
        <select id="follow-up">
          <option value="nein">Nein</option>
          <option value="ja">Ja</option>
        </select>
      </div>
      <div class="wizard-step">
        <label for="walking">Wie stehst du zum Gehen?</label>
        <select id="walking">
          <option value="egal">Egal</option>
          <option value="viel">Ich gehe gern länger</option>
          <option value="wenig">Bitte wenig gehen</option>
        </select>
      </div>
      <div class="wizard-actions">
        <button class="button secondary" id="cancel-wizard">Abbrechen</button>
        <button class="button" id="submit-wizard">Optionen anzeigen</button>
      </div>
    `;
    app.appendChild(container);
    document.getElementById('cancel-wizard').addEventListener('click', () => {
      renderZen();
    });
    document.getElementById('submit-wizard').addEventListener('click', () => {
      // Sammle die Eingaben
      const dest = document.getElementById('destination').value.trim();
      if (!dest) {
        alert('Bitte gib dein Ziel an.');
        return;
      }
      wizardData.destination = dest;
      wizardData.followUp = document.getElementById('follow-up').value;
      wizardData.walking = document.getElementById('walking').value;
      renderComparison();
    });
  }

  // Sample alternatives based on wizard data
  function generateAlternatives() {
    const dest = wizardData.destination;
    const follow = wizardData.followUp === 'ja';
    const walkingPref = wizardData.walking;
    // Basic dynamic details
    const now = new Date();
    function formatTime(date) {
      return date.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
    const baseDuration = walkingPref === 'wenig' ? 30 : walkingPref === 'viel' ? 18 : 24;
    // Build three options
    return [
      {
        id: 'best',
        role: 'Bestes
          Angebot',
        name: `S-Bahn zum ${dest}`,
        description: 'Schnellste Route mit moderatem Gehen',
        duration: baseDuration,
        arrival: formatTime(new Date(now.getTime() + baseDuration * 60000)),
        walking: walkingPref === 'viel' ? '20 Min zu Fuß' : '8 Min zu Fuß',
        notes: follow ? 'Beinhaltet Anschlussplanung' : 'Einfacher Direktweg'
      },
      {
        id: 'calm',
        role: 'Reserviert',
        name: `Tram zum ${dest}`,
        description: 'Mehr Komfort, weniger Tempo',
        duration: baseDuration + 6,
        arrival: formatTime(new Date(now.getTime() + (baseDuration + 6) * 60000)),
        walking: '5 Min zu Fuß',
        notes: 'Minimaler Stress, größere Puffer'
      },
      {
        id: 'fallback',
        role: 'Fallback',
        name: `Bus zum ${dest}`,
        description: 'Langsamer, aber robuste Option',
        duration: baseDuration + 12,
        arrival: formatTime(new Date(now.getTime() + (baseDuration + 12) * 60000)),
        walking: '3 Min zu Fuß',
        notes: 'Geeignet bei Störungen'
      }
    ];
  }

  // Render comparison view with alternatives
  function renderComparison() {
    currentState = 'comparison';
    setModeIndicator('Vergleich', '--color-attentive');
    disruptionButton.style.display = 'none';
    showCathy(true);
    const alternatives = generateAlternatives();
    currentPlan = null;
    const heading = document.createElement('h2');
    heading.textContent = 'Wähle eine Option';
    app.innerHTML = '';
    app.appendChild(heading);
    const container = document.createElement('div');
    container.className = 'options-container';
    alternatives.forEach((opt) => {
      const card = document.createElement('div');
      card.className = 'option-card';
      card.dataset.optId = opt.id;
      card.innerHTML = `
        <div class="role">${opt.role}</div>
        <h3>${opt.name}</h3>
        <div class="details">${opt.description}</div>
        <div class="meta">Ankunft: ${opt.arrival} • Dauer: ${opt.duration} min • Gehen: ${opt.walking}</div>
        <div class="meta">${opt.notes}</div>
      `;
      card.addEventListener('click', () => {
        document.querySelectorAll('.option-card').forEach((c) => c.classList.remove('selected'));
        card.classList.add('selected');
        currentPlan = opt;
      });
      container.appendChild(card);
    });
    app.appendChild(container);
    // Action buttons
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button secondary" id="back-to-wizard">Zurück</button>
      <button class="button" id="select-plan">Weiter</button>
    `;
    app.appendChild(actions);
    document.getElementById('back-to-wizard').addEventListener('click', () => {
      renderWizard();
    });
    document.getElementById('select-plan').addEventListener('click', () => {
      if (!currentPlan) {
        alert('Bitte wähle eine Option aus.');
        return;
      }
      renderExecution(currentPlan);
    });
  }

  // Build execution steps based on chosen plan (simplified)
  function buildSteps(plan) {
    // Use generic pattern: walk -> ride -> walk
    const steps = [];
    const startTime = new Date();
    function addMinutes(date, mins) { return new Date(date.getTime() + mins * 60000); }
    let t = startTime;
    // Step 1: Walk to station
    steps.push({ time: formatTime(t), label: 'Zum Startpunkt gehen', duration: 5, state: 'upcoming' });
    t = addMinutes(t, 5);
    // Step 2: Fahrt
    const rideDuration = plan.duration - 8; // subtract walking both sides
    steps.push({ time: formatTime(t), label: plan.name, duration: rideDuration, state: 'upcoming' });
    t = addMinutes(t, rideDuration);
    // Step 3: Walk to destination
    steps.push({ time: formatTime(t), label: 'Zum Ziel gehen', duration: 3, state: 'upcoming' });
    return steps;
  }
  // Helper to format time
  function formatTime(date) {
    return date.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  }

  // Render execution (Go Mode) view
  function renderExecution(plan) {
    currentState = 'execution';
    currentPlan = plan;
    currentStepIndex = 0;
    setModeIndicator('Go‑Modus', '--color-stable');
    disruptionButton.style.display = 'inline-block';
    showCathy(false);
    // Build steps
    const steps = buildSteps(plan);
    app.innerHTML = '';
    const headerCard = document.createElement('div');
    headerCard.className = 'card';
    headerCard.innerHTML = `
      <h2>Aktueller Plan</h2>
      <p><strong>Route:</strong> ${plan.name}</p>
      <p><strong>Ankunftszeit:</strong> ${plan.arrival}</p>
      <p><strong>Dauer:</strong> ${plan.duration} min</p>
    `;
    app.appendChild(headerCard);
    // Timeline list
    const timeline = document.createElement('ul');
    timeline.className = 'timeline';
    steps.forEach((step, idx) => {
      const li = document.createElement('li');
      li.classList.add(idx === 0 ? 'current' : 'upcoming');
      li.dataset.stepIndex = idx;
      li.innerHTML = `
        <div class="step">
          <span class="timestamp">${step.time}</span>
          <span class="description">${step.label}</span>
        </div>
      `;
      timeline.appendChild(li);
    });
    app.appendChild(timeline);
    // Action button to progress
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button" id="next-step">Nächster Schritt</button>
      <button class="button secondary" id="exit-plan">Plan verlassen</button>
    `;
    app.appendChild(actions);
    document.getElementById('next-step').addEventListener('click', () => {
      advanceStep(timeline);
    });
    document.getElementById('exit-plan').addEventListener('click', () => {
      renderZen();
    });
  }

  // Advance to next step in execution
  function advanceStep(timeline) {
    const items = timeline.querySelectorAll('li');
    if (currentStepIndex < items.length) {
      items[currentStepIndex].classList.remove('current');
      items[currentStepIndex].classList.add('completed');
      currentStepIndex++;
    }
    if (currentStepIndex < items.length) {
      items[currentStepIndex].classList.remove('upcoming');
      items[currentStepIndex].classList.add('current');
    } else {
      // Plan completed
      alert('Reise abgeschlossen!');
      renderZen();
    }
  }

  // Render recovery view
  function renderRecovery() {
    currentState = 'recovery';
    setModeIndicator('Recovery', '--color-urgent');
    disruptionButton.style.display = 'none';
    showCathy(true);
    app.innerHTML = '';
    const recDiv = document.createElement('div');
    recDiv.className = 'recovery';
    recDiv.innerHTML = `
      <h2>Recovery‑Modus</h2>
      <p>Es ist eine Störung aufgetreten. Deine ursprüngliche Route ist nicht mehr zuverlässig. Bitte wähle eine neue Option.</p>
    `;
    app.appendChild(recDiv);
    // Fallback options (use previous plan data to generate simplified options)
    const options = [
      {
        id: 'quick',
        title: 'Schnellster Ausweg',
        desc: 'Zurück zur letzten sicheren Station und alternativen Zug nehmen.'
      },
      {
        id: 'safe',
        title: 'Beruhigte Alternative',
        desc: 'Einen ruhigen Bus nehmen, der dich ans Ziel bringt.'
      }
    ];
    const optsDiv = document.createElement('div');
    optsDiv.className = 'options';
    options.forEach((opt) => {
      const card = document.createElement('div');
      card.className = 'option-card';
      card.innerHTML = `
        <h3>${opt.title}</h3>
        <p>${opt.desc}</p>
      `;
      card.addEventListener('click', () => {
        // choose fallback: treat as new execution with fallback length
        currentPlan = {
          name: opt.title,
          arrival: '–',
          duration: 20,
          walking: '5 Min',
          notes: ''
        };
        renderExecution(currentPlan);
      });
      optsDiv.appendChild(card);
    });
    app.appendChild(optsDiv);
    // Option to cancel journey
    const actions = document.createElement('div');
    actions.className = 'wizard-actions';
    actions.innerHTML = `
      <button class="button secondary" id="cancel-recovery">Reise abbrechen</button>
    `;
    app.appendChild(actions);
    document.getElementById('cancel-recovery').addEventListener('click', () => {
      renderZen();
    });
  }

  // Simulate disruption event
  disruptionButton.addEventListener('click', () => {
    if (currentState === 'execution') {
      renderRecovery();
    }
  });

  // Initial render
  renderZen();
});