# Spatial Assist / Map Focus

## Screen
**Name:** Spatial Assist / Map Focus

## Kurzdefinition
Räumliche Orientierung wird dominanter, aber die Zeit- und Zustandswahrheit bleibt präsent.

## Zweck
Räumliche Orientierung rückt vor, ohne Zeitwahrheit zu verlieren.

## Trigger
Nutzer vertieft Raumhilfe oder nähert sich einem räumlich kritischen Moment

## Nutzerrolle
Raum lesen, ohne den situativen Takt zu verlieren

## CatchIt-Rolle
Karte lesbarer machen, aber Hauptlogik nicht aufgeben

## Primäre Wahrheit
Die Orientierung wird gerade wichtiger, aber die Zeit bleibt maßgeblich.

## Sichtbare Elemente
größere Kartenfläche, klarer Fußweg/Stop-Fokus, Zeitanker weiterhin sichtbar

## Unterdrückte Elemente
reine Karten-App-Logik, Navigationschrome, überladene Kartendetails

## Informationsdichte
mittel

## Tonalität
fokussiert, ruhig, situativ

## Visuelle Konsequenz
Karte gewinnt Raum, aber nicht die komplette Identität

## Darf nicht bedeuten
Google Maps, turn-by-turn takeover

## Kill Criteria
Wenn Zeitinformation verschwindet, wenn die Oberfläche wie eine Standard-Navi wirkt, wenn CatchIt-Hierarchie verloren geht

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
