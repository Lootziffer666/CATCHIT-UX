# Recovery / Simple Switch

## Screen
**Name:** Recovery / Simple Switch

## Kurzdefinition
CatchIt hat eine neue tragfähige Alternative gefunden, ohne den Nutzer unnötig zu belasten.

## Zweck
Sanfte Plananpassung ohne Vertrauensbruch.

## Trigger
ursprüngliche Option wird schlechter, aber eine einfache passende Alternative steht bereit

## Nutzerrolle
zur Kenntnis nehmen, ggf. minimal mitgehen

## CatchIt-Rolle
Änderung erklären, ohne Drama zu erzeugen

## Primäre Wahrheit
Es hat sich geändert. Ich habe eine einfache passende Alternative.

## Sichtbare Elemente
neue Option, knappe Begründung, klare Fortsetzung

## Unterdrückte Elemente
große Problemkommunikation, Alternativenflut

## Informationsdichte
mittel

## Tonalität
beruhigend, kompetent, kurz

## Visuelle Konsequenz
Recovery als Entlastung, nicht als Fehlerzustand

## Darf nicht bedeuten
Fail, Alarm, unkontrollierte Lage

## Kill Criteria
Wenn Recovery wie ein Defekt wirkt, wenn zu viele Wahlmöglichkeiten wieder aufgemacht werden, wenn die neue Tragfähigkeit nicht klar ist

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
