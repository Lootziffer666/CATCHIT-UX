# Go Mode / In Vehicle

## Screen
**Name:** Go Mode / In Vehicle

## Kurzdefinition
Exekutionszustand während der Fahrt. Weniger Losgehstress, mehr Begleitung und Übergangssicherheit.

## Zweck
Begleitender Fahrzustand mit Fokus auf den nächsten sinnvollen Punkt.

## Trigger
Nutzer ist eingestiegen oder befindet sich in der Transportphase

## Nutzerrolle
Folgen, beobachten, sich rechtzeitig vorbereiten

## CatchIt-Rolle
Übergänge absichern, nächste Relevanz früh genug verdichten

## Primäre Wahrheit
Du bist unterwegs. Ich halte den nächsten sinnvollen Punkt für dich im Blick.

## Sichtbare Elemente
nächster relevanter Schritt, verbleibende Stops/Zeit, Umstiegsrelevanz, ruhige Zustandsführung

## Unterdrückte Elemente
initiale Wizard-/Vergleichslogik, zu viele Planungsdetails

## Informationsdichte
niedrig bis mittel

## Tonalität
begleitend, stabil, wachsam

## Visuelle Konsequenz
weniger Hektik als Walk-State, aber klare kommende Relevanz

## Darf nicht bedeuten
reine Fahrtstatusanzeige ohne Handlungsperspektive

## Kill Criteria
Wenn der Screen passiv wird, wenn der nächste relevante Schritt nicht klar lesbar ist, wenn es wie Live-Tracking ohne Entlastung wirkt

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
