# Go Mode / Walk to Stop

## Screen
**Name:** Go Mode / Walk to Stop

## Kurzdefinition
Exekutionszustand für den Weg zur Haltestelle. Denken runter, Handeln rauf.

## Zweck
Exekutionszustand für den Weg zur Haltestelle.

## Trigger
Nutzer muss jetzt losgehen, um die tragfähige Option zu erreichen

## Nutzerrolle
Gehen

## CatchIt-Rolle
Nächsten Schritt maximal klar und belastungsarm machen

## Primäre Wahrheit
Jetzt losgehen. Das ist der Weg.

## Sichtbare Elemente
verbleibende Zeit, verbleibender Weg, Zielhaltestelle, ruhige Raumhilfe

## Unterdrückte Elemente
Mehrfachvergleiche, breite Kettenübersicht, unnötige Nebendetails

## Informationsdichte
fokussiert

## Tonalität
direkt, ruhig, körpernah

## Visuelle Konsequenz
große Klarheit, wenig Auswahl, hohe Exekutionslesbarkeit

## Darf nicht bedeuten
normales Navigationstool, Sport-/Tracking-App

## Kill Criteria
Wenn der Screen wieder zum Analysieren einlädt, wenn zu viele alternative Optionen sichtbar bleiben, wenn die Handlung nicht eindeutig ist

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
