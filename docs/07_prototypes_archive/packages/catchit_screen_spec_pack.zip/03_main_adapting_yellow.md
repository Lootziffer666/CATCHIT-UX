# Main / Adapting / Yellow

## Screen
**Name:** Main / Adapting / Yellow

## Kurzdefinition
Eine Änderung wurde erkannt. CatchIt reagiert bereits und versucht, wieder auf eine tragfähige Lage zu kommen.

## Zweck
Änderung erkannt, CatchIt reagiert bereits.

## Trigger
Verspätung, veränderte Lage, fragliche Anschlusslage, Alternativpfad wird geprüft oder vorbereitet.

## Nutzerrolle
Noch nicht handeln müssen, aber offen für eine Anpassung bleiben.

## CatchIt-Rolle
Kompensieren, neu bewerten, alternative tragfähige Wege vorbereiten.

## Primäre Wahrheit
Etwas hat sich verändert. Ich kümmere mich.

## Sichtbare Elemente
weiter Countdown + Optionen, Hinweis auf veränderte Lage, subtile Zeichen von Anpassung, evtl. neue Passungsmarker

## Unterdrückte Elemente
harte Alarmästhetik, finale Handlungsaufforderung, Rot-Semantik

## Informationsdichte
mittel

## Tonalität
aufmerksam, regulierend, kontrolliert

## Visuelle Konsequenz
leichte Reibung sichtbar, aber keine Panik; Änderung ist lesbar, ohne zum Problem-UI zu kippen

## Darf nicht bedeuten
Warnung, Scheitern, sofort handeln

## Kill Criteria
Wenn Gelb wie Orange aussieht, wenn es wie eine Fehlermeldung wirkt, wenn keine aktive CatchIt-Reaktion erkennbar ist

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
