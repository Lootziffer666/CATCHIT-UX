# Spatial Assist / Map Reveal

## Screen
**Name:** Spatial Assist / Map Reveal

## Kurzdefinition
Der Main Screen verdichtet sich, und aus dem unteren Bereich wird räumliche Unterstützung freigelegt.

## Zweck
Der Main Screen verdichtet sich und legt Raumhilfe frei.

## Trigger
Swipe-up, situativer Bedarf nach räumlicher Sicherheit, Annäherung an Exekution

## Nutzerrolle
Räumlich absichern, ohne den Kernscreen zu verlassen

## CatchIt-Rolle
Orientierung ergänzen, nicht übernehmen

## Primäre Wahrheit
Hier ist zusätzliche Raumhilfe, ohne dass du die Hauptwahrheit verlierst.

## Sichtbare Elemente
gleiche Bubble-Hierarchie, gleiche Optionen, weich eingeblendete Map-Zone unten

## Unterdrückte Elemente
Bottom Sheet, separater Kartenscreen, modulare Dashboard-Blöcke

## Informationsdichte
mittel

## Tonalität
ruhig, eingebettet, unterstützend

## Visuelle Konsequenz
gleiche Oberfläche, höhere Dichte, Karte als untere Schicht

## Darf nicht bedeuten
Map mode, Screenwechsel, Navigation takeover

## Kill Criteria
Wenn die Karte der Hero wird, wenn ein Bottom Sheet sichtbar ist, wenn die Bubble zur Nebenfigur schrumpft

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
