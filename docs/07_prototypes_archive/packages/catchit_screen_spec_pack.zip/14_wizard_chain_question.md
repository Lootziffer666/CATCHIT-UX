# Wizard / Kettenfrage

## Screen
**Name:** Wizard / Kettenfrage

## Kurzdefinition
CatchIt klärt, ob es um einen einzelnen Weg oder einen Tages-/Pflichtablauf mit Folgepunkten geht.

## Zweck
Abgrenzung von Einzelweg und echter Alltagskette.

## Trigger
Nach Wizard-Einstieg oder bei erkennbarer Mehrfachlogik

## Nutzerrolle
Art des Vorhabens beschreiben

## CatchIt-Rolle
Kettenlogik früh und einfach erfassen

## Primäre Wahrheit
Geht es nur um einen Weg, oder hängt heute mehr daran?

## Sichtbare Elemente
alltagsnahe Frageform, einfache Auswahl-/Antwortstruktur

## Unterdrückte Elemente
Flowcharts, komplexe Multi-Step-Builder

## Informationsdichte
niedrig

## Tonalität
pragmatisch, lebensnah

## Visuelle Konsequenz
Kettenlogik erscheint als normaler Alltag, nicht als Sonderfunktion

## Darf nicht bedeuten
Projektplanung, Business-Workflow

## Kill Criteria
Wenn Nutzer die Frage nicht sofort versteht, wenn Kette technisch statt lebensnah wirkt, wenn die UI zu builder-artig wird

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
