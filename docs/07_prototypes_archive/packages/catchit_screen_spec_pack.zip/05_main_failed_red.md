# Main / Failed / Red

## Screen
**Name:** Main / Failed / Red

## Kurzdefinition
Diese konkrete Option oder Kette ist sicher nicht mehr tragfähig.

## Zweck
Eindeutiger Scheiterzustand für eine konkrete Option oder Kette.

## Trigger
Anschluss sicher verpasst, Route nicht mehr rettbar, Zeitfenster faktisch gebrochen.

## Nutzerrolle
Alte Lösung loslassen. Neue Realität akzeptieren.

## CatchIt-Rolle
Klar benennen, nicht beschönigen, neue Basis vorbereiten.

## Primäre Wahrheit
Das klappt so nicht mehr.

## Sichtbare Elemente
eindeutige Problembennung, ggf. neue nächste tragfähige Basis, minimale Rettungs-/Neustartlogik

## Unterdrückte Elemente
kosmetische Zuversicht, weiche Sprache, unnötige Optimierungsdetails

## Informationsdichte
fokussiert niedrig bis mittel

## Tonalität
selten, klar, hart, ehrlich

## Visuelle Konsequenz
Rot nur in eindeutigen Scheiterfällen, kein dekorativer Einsatz

## Darf nicht bedeuten
knapp, fraglich, bitte beeilen

## Kill Criteria
Wenn Rot für bloße Unsicherheit genutzt wird, wenn es wie Orange-plus aussieht, wenn rote Zustände zu häufig auftreten

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
