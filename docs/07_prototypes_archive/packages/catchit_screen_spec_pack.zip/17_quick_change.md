# Quick Change / Snack oder späterer Bus

## Screen
**Name:** Quick Change / Snack oder späterer Bus

## Kurzdefinition
Spontane Abweichung wird in die Kette integriert, ohne alles zu zerstören.

## Zweck
Spontane Abweichung ohne Planungsbruch.

## Trigger
Nutzer möchte kurz etwas einbauen, verschieben oder einen späteren Bus nehmen

## Nutzerrolle
Abweichung äußern, nicht neu planen

## CatchIt-Rolle
Flexibel umsortieren, Tragfähigkeit erhalten

## Primäre Wahrheit
Eine kleine Änderung muss nicht den ganzen Ablauf kaputtmachen.

## Sichtbare Elemente
kleine Änderungsoption, neue plausible Kettenfortsetzung, knappe Auswirkung

## Unterdrückte Elemente
Voll-Neuplanung, lange Listen, komplexe Optionenbäume

## Informationsdichte
mittel

## Tonalität
flexibel, gelassen, lösungsorientiert

## Visuelle Konsequenz
Quick Change fühlt sich leicht an, nicht wie ein großer Eingriff

## Darf nicht bedeuten
kompletter Rebuild, chaotische Re-Optimierung

## Kill Criteria
Wenn die Änderung zu viel UI-Komplexität erzeugt, wenn der Nutzer wieder alles entscheiden muss, wenn Kettenrobustheit nicht sichtbar wird

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
