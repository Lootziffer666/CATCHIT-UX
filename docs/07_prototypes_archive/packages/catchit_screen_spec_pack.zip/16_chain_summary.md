# Chain Summary

## Screen
**Name:** Chain Summary

## Kurzdefinition
CatchIt zeigt, was es aus Vorhaben und Präferenzen verstanden hat und wie daraus tragfähige Vorschläge entstehen.

## Zweck
Zusammenfassung dessen, was CatchIt verstanden hat.

## Trigger
Abschluss des Wizards oder relevante Neujustierung

## Nutzerrolle
Verstanden fühlen, ggf. leicht korrigieren

## CatchIt-Rolle
Verarbeitetes Alltagsmodell sichtbar machen

## Primäre Wahrheit
So denke ich deinen Ablauf und deine Bewegungsrealität mit.

## Sichtbare Elemente
ruhige Kettenübersicht, Präferenzhinweise, verständliche Zusammenfassung

## Unterdrückte Elemente
Settings-Review-Look, rohe Parameterlisten

## Informationsdichte
mittel

## Tonalität
ordnend, vertrauensbildend

## Visuelle Konsequenz
Summary wirkt wie Verständnis, nicht wie Konfiguration

## Darf nicht bedeuten
Bitte kontrollieren Sie 27 Optionen

## Kill Criteria
Wenn die Summary wie ein Einstellungsmenü aussieht, wenn kein klarer Bezug zu späteren Vorschlägen entsteht, wenn zu viel technische Sprache auftaucht

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
