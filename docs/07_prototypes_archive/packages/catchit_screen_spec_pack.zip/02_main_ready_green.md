# Main / Ready / Green

## Screen
**Name:** Main / Ready / Green

## Kurzdefinition
Jetzt wird es relevant, aber der Ablauf ist gut tragfähig.

## Zweck
Relevanz steigt, ohne Hektik auszulösen.

## Trigger
Ein sinnvoller Handlungszeitpunkt nähert sich. Keine problematische Änderung, keine nötige Umplanung.

## Nutzerrolle
Mental bereit sein, bald handeln können.

## CatchIt-Rolle
Relevanz erhöhen, ohne Stress zu erzeugen.

## Primäre Wahrheit
Jetzt wird es wichtig, aber du bist gut aufgestellt.

## Sichtbare Elemente
Countdown-Bubble, 3 Optionen, leicht stärkere operative Zuspitzung, ggf. klarerer Fokus auf die plausibelste aktuelle Option

## Unterdrückte Elemente
Karte, Recovery, übermäßige Vergleichstiefe

## Informationsdichte
niedrig bis leicht erhöht

## Tonalität
zuversichtlich, vorbereitet, wach

## Visuelle Konsequenz
gleiche Hierarchie wie Blau, aber spürbar mehr Relevanz

## Darf nicht bedeuten
Sieg, Optimierung, mathematisch beste Route

## Kill Criteria
Wenn Grün wie Alarm wirkt, wenn der Unterschied zu Blau nur dekorativ ist, wenn der Screen schon wie Exekution aussieht

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
