# Wizard / Einstieg

## Screen
**Name:** Wizard / Einstieg

## Kurzdefinition
CatchIt erklärt seinen Nutzen über Vorhaben und Alltag, nicht über Settings.

## Zweck
Wizard als Hilfe statt Settings-Dschungel.

## Trigger
Erstnutzung oder relevante Neueinrichtung

## Nutzerrolle
Vorhaben und Bewegungsrealität grob mitteilen

## CatchIt-Rolle
Vertrauen aufbauen, nicht wie Setup wirken

## Primäre Wahrheit
Ich will verstehen, wie du unterwegs wirklich funktionieren musst.

## Sichtbare Elemente
einfache, lebensnahe Einstiegsfrage, klare Nutzenkommunikation

## Unterdrückte Elemente
Fachparameter, Schalterfriedhof, technische Begriffe

## Informationsdichte
niedrig

## Tonalität
freundlich, konkret, alltagsnah

## Visuelle Konsequenz
Wizard fühlt sich wie Hilfe an, nicht wie Konfiguration

## Darf nicht bedeuten
Onboarding-Showcase, Formularstrecke

## Kill Criteria
Wenn es wie Settings aussieht, wenn zu viele Entscheidungen auf einmal verlangt werden, wenn der Produktnutzen nicht sofort klar wird

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
