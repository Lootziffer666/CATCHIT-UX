# Recovery / Kette angepasst

## Screen
**Name:** Recovery / Kette angepasst

## Kurzdefinition
Eine Änderung betrifft nicht nur einen Abschnitt, sondern den weiteren Ablauf der Kette.

## Zweck
Änderung mit sichtbarer Folgewirkung auf die Kette.

## Trigger
Zwischenstopp, Rückweg, Folgeverpflichtung oder Zeitkorridor werden durch Änderung mitbeeinflusst

## Nutzerrolle
neue Gesamtlage verstehen, aber nicht alles neu planen müssen

## CatchIt-Rolle
Kettenfolge neu sortieren und als weiter tragfähig darstellen

## Primäre Wahrheit
Die Änderung betrifft mehr als diesen einen Schritt. Ich habe die Kette angepasst.

## Sichtbare Elemente
knappe Kettenfortsetzung, geänderte Folgepunkte, klare neue Logik

## Unterdrückte Elemente
Planungschaos, vollständige Neuberechnung als Textwand

## Informationsdichte
mittel bis hoch, aber strukturiert

## Tonalität
ordnend, souverän, entlastend

## Visuelle Konsequenz
Kettenhaftigkeit wird sichtbar, ohne Projektplan-Charakter

## Darf nicht bedeuten
Voll-Neuplanung durch den Nutzer

## Kill Criteria
Wenn die Kette nicht visuell verständlich wird, wenn zu viel Text nötig ist, wenn es wie ein kompliziertes Planungstool aussieht

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
