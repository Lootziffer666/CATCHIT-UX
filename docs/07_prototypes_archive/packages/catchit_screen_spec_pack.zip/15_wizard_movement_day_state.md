# Wizard / Bewegungsstil / Tageslage

## Screen
**Name:** Wizard / Bewegungsstil / Tageslage

## Kurzdefinition
Präferenzen und aktuelle Belastungsfaktoren werden so erhoben, dass spätere Vorschläge realistisch passen.

## Zweck
Reibungsprofil statt Parametereinstellungen.

## Trigger
nach Kettenfrage oder bei relevanter Profilbildung

## Nutzerrolle
Bewegungsrealität und Tagesbesonderheiten angeben

## CatchIt-Rolle
Reibungsprofil statt Settings-Liste erfassen

## Primäre Wahrheit
Was heute oder grundsätzlich deine Bewegung verändert, soll mitgedacht werden.

## Sichtbare Elemente
einfache Auswahlfelder, alltagsnahe Formulierungen, kind-/stress-/geh-/wartebezogene Faktoren

## Unterdrückte Elemente
technische Filter, schwere Parameterbegriffe

## Informationsdichte
niedrig bis mittel

## Tonalität
empathisch, praktisch, unprätentiös

## Visuelle Konsequenz
kein Klinik-/Assessment-Gefühl, keine Settings-Hölle

## Darf nicht bedeuten
Diagnostik, Profiling, Formularprüfung

## Kill Criteria
Wenn die Fragen klinisch oder technisch wirken, wenn Antworten später nicht sichtbar auf Vorschläge einzahlen, wenn es wie versteckte Settings wirkt

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
