# Recovery / Recheck nötig

## Screen
**Name:** Recovery / Recheck nötig

## Kurzdefinition
CatchIt kann die Lage nicht glatt genug halten und braucht erneute Nutzeraufmerksamkeit.

## Zweck
Unsicherheit wird ehrlich an den Nutzer zurückgegeben.

## Trigger
Datenlage unsicher, Alternativen nicht belastbar genug, neue Prüfung nötig

## Nutzerrolle
nochmal hinschauen, aktiv bestätigen oder neu bewerten

## CatchIt-Rolle
ehrlich Unsicherheit markieren, ohne Vertrauen zu verspielen

## Primäre Wahrheit
Ich kann das gerade nicht sauber genug für dich übernehmen. Bitte prüf nochmal.

## Sichtbare Elemente
Unsicherheitsgrund, Recheck-Aufforderung, reduzierte klare Optionen

## Unterdrückte Elemente
falsche Sicherheit, beschönigende Sprache

## Informationsdichte
mittel

## Tonalität
ehrlich, nüchtern, respektvoll

## Visuelle Konsequenz
nicht alarmistisch, aber klar von Simple Switch getrennt

## Darf nicht bedeuten
generischer Fehler, technischer Defekt, bloßes Gelb

## Kill Criteria
Wenn unklar bleibt, warum Recheck nötig ist, wenn der Nutzer keine klare nächste Handlung erkennt, wenn der Zustand sich wie ein App-Bug anfühlt

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
