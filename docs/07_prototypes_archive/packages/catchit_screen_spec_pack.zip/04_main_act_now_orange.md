# Main / Act Now / Orange

## Screen
**Name:** Main / Act Now / Orange

## Kurzdefinition
Eine sinnvolle Lösung ist vorhanden, aber jetzt ist Nutzerhandlung nötig.

## Zweck
Jetzt reicht Beobachtung nicht mehr; Handlung ist nötig.

## Trigger
Der Nutzer muss jetzt losgehen, wechseln, reagieren oder sich für eine noch tragfähige Option entscheiden.

## Nutzerrolle
Handeln. Nicht mehr nur beobachten.

## CatchIt-Rolle
Interpretationslast reduzieren, nächsten Schritt glasklar machen.

## Primäre Wahrheit
Jetzt handeln, dann bleibt es machbar.

## Sichtbare Elemente
klare Exekutionssignale, verdichtete Informationen, nächste Handlung prominent, ggf. Raumhilfe/Karte stärker zugänglich

## Unterdrückte Elemente
breite Vergleichsinfos, ruhige Neutralität, unnötige Nebendetails

## Informationsdichte
mittel bis hoch, aber fokussiert

## Tonalität
direkt, klar, exekutiv

## Visuelle Konsequenz
stärkere Verdichtung, weniger Optionalität, Fokus auf nächste Aktion

## Darf nicht bedeuten
gescheitert, hoffnungslos, final verloren

## Kill Criteria
Wenn Orange wie Rot aussieht, wenn der Nutzer nicht sofort versteht, was zu tun ist, wenn zu viele Optionen gleichzeitig sichtbar bleiben

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
