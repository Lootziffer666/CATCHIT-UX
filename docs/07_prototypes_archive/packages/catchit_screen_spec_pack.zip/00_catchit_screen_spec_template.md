# CatchIt Screen Spec Template

## Verwendung
Diese Vorlage ist für einzelne CatchIt-Screens gedacht.
Sie trennt bewusst zwischen Zustand, Nutzerrolle, CatchIt-Rolle und UI-Konsequenz, damit klassische App-Muster nicht heimlich wieder hereinkriechen.

## Screen
**Name:**  
**ID / Dateiname:**  
**Familie:** Main / Spatial Assist / Go Mode / Recovery / Wizard / Chain / Trust  
**Priorität:** P1 / P2 / P3 / P4

## 1. Kurzdefinition

## 2. Zweck

## 3. Trigger

## 4. Nutzerrolle

## 5. CatchIt-Rolle

## 6. Primäre Wahrheit

## 7. Sichtbare Elemente

## 8. Unterdrückte Elemente

## 9. Informationsdichte

## 10. Tonalität

## 11. Visuelle Konsequenz

## 12. Darf nicht bedeuten

## 13. Kill Criteria

## 14. Invarianten

## 15. Variablen

## 16. Suitability / Trust Logic

## 17. Prompt Guardrails für Stitch
- not a generic transit app
- not a route results list
- not a dashboard
- not a bottom sheet unless explicitly intended
- preserve CatchIt hierarchy
- preserve state meaning before adding UI detail
