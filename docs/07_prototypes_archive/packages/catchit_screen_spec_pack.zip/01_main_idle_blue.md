# Main / Idle / Blue

## Screen
**Name:** Main / Idle / Blue

## Kurzdefinition
Noch kein akuter Handlungsdruck. CatchIt hält die Lage ruhig, klar und lesbar.

## Zweck
Nullpunkt der App; ruhige Primärwahrheit ohne akuten Handlungsdruck.

## Trigger
Route/Kette ist vorhanden, aber noch nicht operativ relevant. Keine störende Abweichung, kein unmittelbarer Entscheidungsdruck.

## Nutzerrolle
Beobachten dürfen, nicht nachdenken müssen.

## CatchIt-Rolle
Überwachen, beruhigen, vorverdichten, aber nicht zuspitzen.

## Primäre Wahrheit
Es ist alles vorbereitet. Noch ist nichts akut.

## Sichtbare Elemente
große Countdown-Bubble, 3 präferenzgebundene Optionen, ruhige Grundstruktur, minimale Zusatzinfos

## Unterdrückte Elemente
Karte, Recovery-Logik, aggressive Statussignale, detaillierte Vergleichsinfos

## Informationsdichte
niedrig

## Tonalität
ruhig, souverän, beiläufig präsent

## Visuelle Konsequenz
viel Luft, stabile Vertikalachse, keine operative Verdichtung

## Darf nicht bedeuten
leer, unwichtig, datenarm, passiv

## Kill Criteria
Wenn der Screen wie eine Startseite ohne Relevanz wirkt, wenn schon Hektik entsteht, wenn zu viele Details sichtbar sind, wenn die 3 Optionen wie Suchresultate aussehen

## Invarianten
- Countdown-/Zustandslogik als Vertrauensanker erhalten, sofern der State nicht explizit davon abweicht.
- CatchIt darf nicht in generische Transit-, Karten- oder Dashboard-UI kippen.

## Variablen
- Dichte, Ton, Kartenanteil, Recovery-Botschaft und Exekutionsschärfe dürfen je State variieren.

## Suitability / Trust Logic
- Dieser State muss Passung, Tragfähigkeit oder Vertrauenslogik sichtbar machen, nicht nur Daten anzeigen.

## Prompt Guardrails für Stitch
- same screen logic where applicable
- preserve CatchIt hierarchy
- do not turn this into a generic transit app
- do not invent route-results-list behavior
- preserve state meaning before adding UI detail
