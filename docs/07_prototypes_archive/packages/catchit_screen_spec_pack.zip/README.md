# CatchIt Screen Spec Pack

Dieses Paket enthält:
- `00_catchit_screen_spec_template.md` als leere Master-Vorlage
- 17 vorgefüllte Markdown-Dateien für die definierten CatchIt-Zustände

## Struktur
1. Main States
2. Spatial Assist
3. Go Mode
4. Recovery
5. Wizard / Chain / Quick Change

## Hinweis
Die Dateien sind absichtlich dokumentationsfähig und prompttauglich gehalten.
Sie eignen sich für Figma-Annotations, Stitch-Briefings, Design-Dokumente und Pitch-Unterlagen.
