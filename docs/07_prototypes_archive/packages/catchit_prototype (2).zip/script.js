// State management for screens
const screens = {
    zen: document.getElementById('screen-zen'),
    planning: document.getElementById('screen-planning'),
    compare: document.getElementById('screen-compare'),
    execute: document.getElementById('screen-execute'),
    recovery: document.getElementById('screen-recovery')
};

function showScreen(name) {
    Object.values(screens).forEach(screen => screen.classList.remove('active'));
    screens[name].classList.add('active');
}

// Event listeners
const startPlanningBtn = document.getElementById('startPlanningBtn');
const planningNextBtn = document.getElementById('planningNextBtn');
const chooseOptionBtn = document.getElementById('chooseOptionBtn');
const toRecoveryBtn = document.getElementById('toRecoveryBtn');
const replanBtn = document.getElementById('replanBtn');
const endBtn = document.getElementById('endBtn');

startPlanningBtn.addEventListener('click', () => {
    showScreen('planning');
    buildHorizontalTimeline();
});

planningNextBtn.addEventListener('click', () => {
    // Simulate generating options based on input
    buildOptions();
    showScreen('compare');
});

chooseOptionBtn.addEventListener('click', () => {
    // Build vertical timeline based on selected option
    buildVerticalTimeline();
    showScreen('execute');
    startCountdown();
});

toRecoveryBtn.addEventListener('click', () => {
    showScreen('recovery');
});

replanBtn.addEventListener('click', () => {
    showScreen('planning');
});

endBtn.addEventListener('click', () => {
    showScreen('zen');
});

// Weekday selection
const weekdays = document.querySelectorAll('.weekday');
weekdays.forEach(day => {
    day.addEventListener('click', () => {
        weekdays.forEach(d => d.classList.remove('active'));
        day.classList.add('active');
    });
});

// Build horizontal timeline for planning
function buildHorizontalTimeline() {
    const timeline = document.getElementById('horizontalTimeline');
    timeline.innerHTML = '';
    // Example: 4 planning steps
    const steps = ['Start', 'Optionen', 'Bestätigen', 'Fertig'];
    steps.forEach((label) => {
        const point = document.createElement('div');
        point.classList.add('point');
        const span = document.createElement('span');
        span.classList.add('label');
        span.textContent = label;
        point.appendChild(span);
        timeline.appendChild(point);
        // adjust spacing via flex property
        point.style.flex = '1';
    });
}

// Build options cards for comparison screen
function buildOptions() {
    const optionsGrid = document.getElementById('optionsGrid');
    optionsGrid.innerHTML = '';
    const options = [
        { id: 1, title: 'Schnell', duration: '25 min', cost: '2,90 €', changes: '1x Umsteigen' },
        { id: 2, title: 'Günstig', duration: '32 min', cost: '2,40 €', changes: '0x Umsteigen' },
        { id: 3, title: 'Komfort', duration: '30 min', cost: '3,10 €', changes: '1x Umsteigen' }
    ];
    options.forEach(opt => {
        const card = document.createElement('div');
        card.classList.add('option-card');
        card.dataset.optionId = opt.id;
        card.innerHTML = `<strong>${opt.title}</strong><br>Dauer: ${opt.duration}<br>Kosten: ${opt.cost}<br>${opt.changes}`;
        card.addEventListener('click', () => {
            document.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
        });
        optionsGrid.appendChild(card);
    });
    // default select first
    const firstCard = optionsGrid.querySelector('.option-card');
    if (firstCard) firstCard.classList.add('selected');
}

// Build vertical timeline for execution
let verticalEvents = [];
function buildVerticalTimeline() {
    const verticalTimeline = document.getElementById('verticalTimeline');
    verticalTimeline.innerHTML = '';
    // Example timeline events; times relative to now
    const now = new Date();
    verticalEvents = [
        { label: 'Losgehen', offset: 0, icon: '🚶' },
        { label: 'Bus nehmen', offset: 5, icon: '🚌' },
        { label: 'Umsteigen', offset: 15, icon: '🔁' },
        { label: 'Ankunft', offset: 25, icon: '🏁' }
    ];
    verticalEvents.forEach(event => {
        const li = document.createElement('li');
        li.classList.add('future');
        const timeEl = document.createElement('div');
        timeEl.classList.add('time');
        const eventTime = new Date(now.getTime() + event.offset * 60000);
        const hours = eventTime.getHours().toString().padStart(2, '0');
        const minutes = eventTime.getMinutes().toString().padStart(2, '0');
        timeEl.textContent = `${hours}:${minutes}`;
        const iconEl = document.createElement('div');
        iconEl.classList.add('icon');
        iconEl.textContent = event.icon;
        const labelEl = document.createElement('div');
        labelEl.classList.add('label');
        labelEl.textContent = event.label;
        li.appendChild(timeEl);
        li.appendChild(iconEl);
        li.appendChild(labelEl);
        verticalTimeline.appendChild(li);
    });
}

// Countdown logic
let countdownInterval;
function startCountdown() {
    clearInterval(countdownInterval);
    const countdownElem = document.getElementById('countdown');
    const verticalItems = document.querySelectorAll('#verticalTimeline li');
    let currentIndex = 0;
    // Initialize classes
    verticalItems.forEach(li => li.classList.remove('active', 'completed', 'future'));
    verticalItems.forEach(li => li.classList.add('future'));
    if (verticalItems.length > 0) {
        verticalItems[0].classList.remove('future');
        verticalItems[0].classList.add('active');
    }
    let remainingSeconds = verticalEvents[0].offset * 60;
    updateCountdownDisplay(remainingSeconds);
    countdownInterval = setInterval(() => {
        remainingSeconds--;
        if (remainingSeconds < 0) {
            // Move to next event
            verticalItems[currentIndex].classList.remove('active');
            verticalItems[currentIndex].classList.add('completed');
            currentIndex++;
            if (currentIndex >= verticalEvents.length) {
                clearInterval(countdownInterval);
                countdownElem.textContent = '00:00';
                return;
            }
            verticalItems[currentIndex].classList.remove('future');
            verticalItems[currentIndex].classList.add('active');
            remainingSeconds = (verticalEvents[currentIndex].offset - verticalEvents[currentIndex - 1].offset) * 60;
        }
        updateCountdownDisplay(remainingSeconds);
    }, 1000);
}

function updateCountdownDisplay(seconds) {
    const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
    document.getElementById('countdown').textContent = `${minutes}:${secs}`;
}