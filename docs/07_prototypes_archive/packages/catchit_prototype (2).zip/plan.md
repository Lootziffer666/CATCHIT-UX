# CatchIt Prototyp – Architekturplan

## Überblick

Dieser Prototyp veranschaulicht das Prinzip der horizontalen Planung und der vertikalen Ausführung für eine Mobilitäts‑App. Eine **harte Konstante**, dargestellt als Punkt/Kreis in der Kopfzeile, dient als kognitiver Anker über alle Zustände hinweg. Die Planungsebene ist horizontal und explorativ, während die Ausführung vertikal, sequenziell und verdichtet ist. Ein Sicherheitsindikator (weiß/gold) befindet sich permanent in der Kopfzeile und signalisiert den Zustand des Systems.

## Zustandsmodell

| Modus | Beschreibung |
|---|---|
| **Zen (Übersicht)** | Minimale Einstiegssicht. Nur der Anker und eine kurze Aufforderung. Von hier startet der Planungs‑Wizard. |
| **Planung (Wizard)** | Der Nutzer gibt sein Ziel oder eine Aufgabe ein und wählt Datum/Uhrzeit. Ein horizontaler Zeitstrahl mit Punkten zeigt den Fortschritt durch die Planungs‑schritte (Start → Optionen → Bestätigen → Fertig). |
| **Vergleich** | Mehrere Routen‑ oder Vorgehensvorschläge werden als Karten angezeigt. Der Nutzer wählt eine Option. |
| **Ausführung (Go)** | Die Planung wird in eine vertikale Timeline überführt. Der Anker wird zum Countdown‑Timer. Jeder Schritt (Losgehen, Bus nehmen, Umsteigen, Ankunft) erscheint als Element mit Uhrzeit, Icon und Label. Vergangene Schritte sind abgeblendet, der aktuelle Schritt ist hervorgehoben und zukünftige Schritte sind neutral. |
| **Recovery** | Bei Unterbrechungen bietet der Recovery‑Screen Optionen zum Neuplanen oder Beenden der aktuellen Session. |

## Harte Konstanten

- **Gerätekontainer & Navigation Chrome:** Der obere Bereich (Header) bleibt über alle Frames gleich groß und beinhaltet den Anker und den Sicherheitsindikator.
- **Entscheidungsanker:** Der Punkt links oben fungiert als Fixpunkt. In der Ausführung wird er zum Countdown‑Timer; seine Position bleibt jedoch unverändert.
- **Sicherheitsindikator:** Ein kleiner Kreis mit weißer Füllung und goldener Umrandung signalisiert Verbindungs‑ oder Systemstatus.

## Bewegungsregeln

- **Horizontale Planung → Vertikale Ausführung:** Der Nutzer bewegt sich zunächst entlang eines horizontalen Pfades, um Optionen zu sammeln und Entscheidungen zu treffen. Nach Abschluss wird der Plan vertikal verdichtet. Die Punkte des horizontalen Pfades werden zu Sequenzschritten in der Timeline.
- **Verdichtung:** In der Ausführung reduzieren sich Abstände und Elemente, um den Fokus zu erhöhen. In der Planung hingegen wirken Abstände großzügiger, um Exploration zu erleichtern.
- **Easing:** Übergänge zwischen Zuständen erfolgen sanft über CSS‑Klassen und JavaScript (kein hartes Umschalten). Dies kann in einer erweiterten Version animiert werden.

## Dateistruktur

```
catchit_prototype/
├── index.html         – Hauptseite, enthält Struktur aller Screens und bindet CSS/JS ein
├── styles.css         – Enthält Styles für Layout, Farben, Buttons, Timeline‑Elemente und Responsivität
├── script.js          – JavaScript für die Zustandssteuerung, Timeline‑Generierung und den Countdown
└── plan.md            – Diese Dokumentation
```

## Implementierungsdetails

- **Responsives Layout:** Die App ist für Mobilgeräte (max. 420 px Breite) optimiert. Sie verwendet Flexbox‑Layouts, um Elemente sowohl horizontal als auch vertikal auszurichten.
- **Interaktive Elemente:**
  - Im Planungs‑Screen kann der Nutzer Wochentage auswählen. Der gewählte Tag wird farblich markiert.
  - Ein horizontaler Zeitstrahl visualisiert die vier Planungs‑schritte. Er wird dynamisch erstellt, damit die Struktur später erweitert werden kann.
  - Im Vergleichs‑Screen werden drei Optionskarten generiert. Der Nutzer wählt eine Option durch Antippen.
  - Bei Auswahl einer Option wird eine vertikale Timeline mit relativen Offsets erzeugt. Diese Offsets lassen sich in einer echten Integration aus echten Fahrplandaten ableiten.
- **Countdown‑Mechanik:** Ein Timer zählt die Sekunden bis zum nächsten Schritt herunter. Sobald ein Schritt abgeschlossen ist, wechselt die Klasse des Listenelements von `active` zu `completed`, und der nächste Schritt wird aktiv. Das Countdown‑Label aktualisiert sich laufend.
- **Neutraler Farbkanon:** Die gewählte Farbpalette ist dezent (Blau‑ und Grautöne). Der goldene Rand des Sicherheitsindikators ist die einzige warme Farbe und zieht so Aufmerksamkeit auf den Systemstatus.
- **Erweiterbarkeit:** Die Struktur trennt Logik und Präsentation (HTML vs. CSS vs. JS). Zusätzliche Screens wie ein Vergleich von Alternativen oder eine detaillierte Kartenansicht können in neuen Sections angelegt und über `showScreen()` aktiviert werden.

## Nutzung des Prototyps

1. **Starten:** Auf dem Zen‑Screen auf „Planung beginnen“ tippen.
2. **Planung:** Ziel/Task eingeben, Datum und Uhrzeit wählen, durch die horizontale Planung navigieren und „Weiter“ antippen.
3. **Vergleich:** Eine der vorgeschlagenen Optionen auswählen und „Start“ tippen.
4. **Ausführen:** Der Countdown startet und zeigt die verbleibende Zeit bis zum nächsten Schritt. Die Timeline verdichtet sich vertikal. Über „Recovery“ gelangt man in einen Modus zur Unterbrechung.
5. **Recovery:** Hier kann der Nutzer neu planen oder die Session beenden. Nach dem Beenden kehrt der Prototyp in den Zen‑Screen zurück.

Dieser Prototyp demonstriert das zentrale UX‑Konzept, ohne sich in visueller Brand‑Ausgestaltung zu verlieren. Er dient als Basis für weitere Iterationen, die beispielsweise Kartenintegration, echte Fahrplandaten oder Accessibility‑Features (Cathy‑Layer) hinzufügen.