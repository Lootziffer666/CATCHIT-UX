# CATCHIT UX‑Plan

## Überblick

Diese UX dient als unabhängige Webversion der CatchIt‑Planungslogik. Sie berücksichtigt die harten Konstanten (Gerätekontainer, Navigations‑Chrome, Entscheidungsanker) und die Unterscheidung zwischen horizontaler Planung und vertikaler Ausführung.

## Dateien und ihre Funktion

- **style.css**: zentrale Styles; definiert Farben, Ringe, Timeline, Karten und responsive Verhalten.
- **index.html**: Zen‑Übersicht. Zeigt eine Zusammenfassung des Tages, den Entscheidungsanker und Verknüpfungen zu den weiteren Ansichten.
- **wizard.html**: Planung. Der Nutzer wählt aus vordefinierten Zielen (bzw. gibt bei Bedarf einen eigenen Ort ein) und legt Datum, Zeit und Wiederholung fest. Die horizontale Planungslinie (planning‑bar) visualisiert jeden Schritt als Punkt.
- **compare.html**: Vergleich. Zeigt alternative Wege mit Zeit, Entfernung, Kosten und erlaubt die Auswahl. Ausgewählte Optionen werden im Plan gespeichert.
- **timeline.html**: Vertikale Ausführung. Wandelt die Punkte aus der Planung in eine Timeline mit Haltepunkten und aktiviert einen Countdown‑Ring mit goldenem Füllstand.
- **recovery.html**: Recovery‑Modus. Bietet Optionen zur Neuplanung oder zum Anfordern von Hilfe.
- **script.js**: Gemeinsame Logik (Speichern/Laden des Plans, Darstellung der Ringe, Aufbau von Timeline und Alternativen, Countdown).

## Zustandsfolge

1. **Zen‑Übersicht (index.html)**: Der Nutzer sieht kommende Termine/Pläne. Der Ring zeigt die Minuten bis zum nächsten Ereignis.
2. **Planung (wizard.html)**: Beginn einer neuen Planung. Der Entscheidungsanker (Ring) begleitet den Prozess. Schritte: Zielwahl, Datum, Zeit, Wiederholung.
3. **Vergleich (compare.html)**: Alternative Routen werden angeboten. Auswahl führt zur Ausführung.
4. **Ausführung (timeline.html)**: Die Punkte aus der Planung werden zu vertikalen Haltepunkten mit Zeiten. Der Ring wechselt vom Planungsanker zum Countdown‑Timer und füllt sich golden für die Sicherheitsreserve.
5. **Recovery (recovery.html)**: Bei Störungen zeigt dieser Modus Optionen (neustarten, neu planen, Hilfe).

## Designprinzipien

- **Horizontale Planung**: Die Planung wird als Abfolge von Punkten auf einer Linie dargestellt. Schritte sind luftig und explorativ.
- **Vertikale Ausführung**: In der Ausführung werden diese Punkte zu einer dichten Timeline. Die Informationen werden sequenziell und handlungsorientiert.
- **Entscheidungsanker**: Ein Ring, der in allen Zuständen präsent bleibt. In der Planung markiert er den Start; in der Ausführung wird er zum Countdown‑Timer mit goldenem Füllstand.
- **Navigations‑Chrome**: Einfaches, stets sichtbares Menü mit Links zu den Kernansichten.
- **Sicherheitsindikator**: Der Ring füllt sich mit einem goldenen Balken, um Zeitreserven oder Verzögerungen anzuzeigen.
- **Modularität**: Alle Teile sind voneinander entkoppelt. Der Plan wird in `localStorage` gehalten, sodass der Zustand über Seiten hinweg erhalten bleibt.

Die implementierten Dateien können als Basis für eine produktionsreife Web‑ oder Hybrid‑App genutzt werden und sind strukturiert, sodass sie später mit echten Datenquellen und dem CatchIt‑Mobilitätskern verbunden werden können.