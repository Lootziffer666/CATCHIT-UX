// Utils für Storage
function savePlan(plan) {
    localStorage.setItem('currentPlan', JSON.stringify(plan));
}
function loadPlan() {
    return JSON.parse(localStorage.getItem('currentPlan') || '{}');
}

// Wizard‑Verhalten
document.addEventListener('DOMContentLoaded', () => {
    const goalSelect = document.getElementById('goal');
    const customGoalContainer = document.getElementById('customGoalContainer');
    const planningBar = document.getElementById('planningBar');
    const ring = document.getElementById('planRing');

    if (goalSelect) {
        goalSelect.addEventListener('change', () => {
            customGoalContainer.style.display = goalSelect.value === 'custom' ? 'block' : 'none';
        });

        document.getElementById('wizardForm').addEventListener('submit', e => {
            e.preventDefault();
            // Baue Planobjekt
            const plan = {
                goal: goalSelect.value === 'custom' ? document.getElementById('customGoal').value : goalSelect.options[goalSelect.selectedIndex].text,
                date: document.getElementById('date').value,
                time: document.getElementById('time').value,
                repeat: document.getElementById('repeat').value,
                alternatives: [
                    { route: "Linie 21", time: 24, cost: 3.6, distance: 10.2 },
                    { route: "Linie 295", time: 26, cost: 3.3, distance: 9.8 },
                    { route: "Zu Fuß", time: 40, cost: 0, distance: 8.5 }
                ]
            };
            savePlan(plan);
            window.location.href = 'compare.html';
        });
    }

    // Vergleichsseite
    const compareContainer = document.getElementById('compareContainer');
    if (compareContainer) {
        const plan = loadPlan();
        if (plan.alternatives) {
            plan.alternatives.forEach((alt, index) => {
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = `
                    <h3>${alt.route}</h3>
                    <p>Dauer: ${alt.time} min</p>
                    <p>Distanz: ${alt.distance.toFixed(1)} km</p>
                    <p>Kosten: ${alt.cost.toFixed(2)} €</p>
                    <button onclick="selectAlternative(${index})">Wählen</button>
                `;
                compareContainer.appendChild(card);
            });
        }
    }

    // Timeline‑Seite
    const timelineList = document.getElementById('timelineList');
    if (timelineList) {
        const plan = loadPlan();
        if (plan.goal) {
            const timeSteps = [
                { label: "Losgehen", time: plan.time },
                { label: plan.goal, time: addMinutes(plan.time, 24) }
            ];
            timeSteps.forEach((step, i) => {
                const item = document.createElement('div');
                item.className = 'timeline-item';
                item.innerHTML = `
                    <div class="bullet ${i === 0 ? 'completed' : ''}"></div>
                    <div class="content">
                        <div class="time">${step.time}</div>
                        <div class="label">${step.label}</div>
                    </div>
                `;
                timelineList.appendChild(item);
            });
            startCountdown(plan.time);
        }
    }

    // Überblicks‑Ring initialisieren
    const overviewRing = document.getElementById('overviewRing');
    if (overviewRing) {
        const plan = loadPlan();
        if (plan.time) {
            const remaining = getMinutesUntil(plan.date, plan.time);
            overviewRing.textContent = `${remaining}m`;
        }
    }
});

// Hilfsfunktionen
function addMinutes(timeString, minutes) {
    const [h, m] = timeString.split(':').map(Number);
    const date = new Date();
    date.setHours(h, m + minutes);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function getMinutesUntil(dateString, timeString) {
    const now = new Date();
    const target = new Date(dateString + 'T' + timeString);
    const diff = Math.max(0, Math.round((target - now) / 60000));
    return diff;
}

// Auswahl einer Alternative
function selectAlternative(index) {
    const plan = loadPlan();
    plan.selected = index;
    savePlan(plan);
    window.location.href = 'timeline.html';
}

function proceedToTimeline() {
    window.location.href = 'timeline.html';
}

function startCountdown(timeString) {
    const ring = document.getElementById('timelineRing') || document.getElementById('overviewRing');
    function update() {
        const plan = loadPlan();
        const remaining = getMinutesUntil(plan.date, timeString);
        ring.textContent = `${remaining}m`;
        // Fülle den Ring proportional (0–1), hier grob über 60 Minuten skaliert
        const percentage = Math.max(0, Math.min(1, remaining / 60));
        ring.style.setProperty('--fill', (1 - percentage) * 100 + '%');
        if (remaining > 0) setTimeout(update, 60000);
    }
    update();
}

// Navigation aus Recovery
function retryPlan() {
    window.location.href = 'timeline.html';
}
function openWizard() {
    window.location.href = 'wizard.html';
}
function callHelp() {
    alert('Hilfe wird verständigt.');
}
function goToRecovery() {
    window.location.href = 'recovery.html';
}